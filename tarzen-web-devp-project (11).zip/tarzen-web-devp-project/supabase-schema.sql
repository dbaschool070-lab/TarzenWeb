-- Tarzen Web Devp. — Supabase schema
-- HOW TO USE: Supabase Dashboard → SQL Editor → New query → paste this whole file → Run.
-- Run it ONCE before real customers use the app. It creates the tables the code expects
-- (see TABLES in src/js/supabase.js), basic Row Level Security, and the storage buckets.
-- After running, set your real admin email in the "settings" seed / Admin Panel.

create extension if not exists "pgcrypto";

-- ---------- Tables ----------
create table if not exists public.users (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  name text, phone text, city text,
  role text not null default 'customer',          -- customer | admin
  blocked boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.users(id) on delete set null,
  name text, phone text, email text,
  business_name text, address text, city text, state text, pincode text, gst text, reference text,
  category text not null,                          -- one of the 9 categories
  plan text,                                       -- monthly | yearly | onetime | withcode
  amount_usd numeric, amount_inr numeric, discount_inr numeric default 0, coupon text,
  status text not null default 'pending_review',
    -- form_submitted | demo_viewed | payment_pending | screenshot_uploaded | pending_review | approved | rejected | delivered
  message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references public.orders(id) on delete cascade,
  screenshot_url text,                             -- path in the "screenshots" bucket
  amount_inr numeric,
  status text not null default 'pending',          -- pending | verified | rejected
  created_at timestamptz not null default now()
);

create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references public.orders(id) on delete cascade,
  type text not null,                              -- bill | agreement | receipt
  size text not null,                              -- A4 | A5
  file_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.coupons (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  type text not null default 'percent',            -- percent | flat-inr
  value numeric not null default 0,
  active boolean not null default true,
  expires_at date, usage_limit int,
  created_at timestamptz not null default now()
);

create table if not exists public.tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.users(id) on delete set null,
  subject text, message text,
  status text not null default 'open',             -- open | replied | closed | escalated
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.users(id) on delete cascade,
  title text, body text,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.settings (
  id int primary key default 1,
  company jsonb not null default '{}'::jsonb,      -- name, address, gst, phone, email, logo, stamp, signature
  pricing jsonb not null default '{}'::jsonb,      -- monthly, yearly, onetime, withcode, maintenance, gstPercent
  qr jsonb not null default '{}'::jsonb,           -- image, upiId
  usd_inr numeric default 83.5,
  updated_at timestamptz not null default now(),
  constraint settings_single_row check (id = 1)
);

create table if not exists public.activity_logs (
  id uuid primary key default gen_random_uuid(),
  actor text, action text, details text,
  created_at timestamptz not null default now()
);

insert into public.settings (id) values (1) on conflict (id) do nothing;
insert into public.coupons (code, type, value) values
  ('WELCOME10','percent',10), ('FIRST50','flat-inr',50)
on conflict (code) do nothing;

-- ---------- Row Level Security ----------
-- Basic starter policies: logged-in users manage their own rows; orders/documents are
-- readable by their owner. Tighten these (and add an admin policy based on users.role)
-- before public launch — review every policy in Dashboard → Authentication → Policies.
alter table public.users enable row level security;
alter table public.orders enable row level security;
alter table public.payments enable row level security;
alter table public.documents enable row level security;
alter table public.coupons enable row level security;
alter table public.tickets enable row level security;
alter table public.notifications enable row level security;
alter table public.settings enable row level security;
alter table public.activity_logs enable row level security;

create policy "users: own row" on public.users
  for all using (auth.jwt() ->> 'email' = email) with check (auth.jwt() ->> 'email' = email);
create policy "orders: owner access" on public.orders
  for all using (auth.jwt() ->> 'email' = email) with check (auth.jwt() ->> 'email' = email);
create policy "payments: via own order" on public.payments
  for all using (exists (select 1 from public.orders o where o.id = order_id and o.email = auth.jwt() ->> 'email'))
  with check (exists (select 1 from public.orders o where o.id = order_id and o.email = auth.jwt() ->> 'email'));
create policy "documents: via own order" on public.documents
  for select using (exists (select 1 from public.orders o where o.id = order_id and o.email = auth.jwt() ->> 'email'));
create policy "coupons: read active" on public.coupons for select using (active = true);
create policy "tickets: owner access" on public.tickets
  for all using (user_id in (select id from public.users where email = auth.jwt() ->> 'email'))
  with check (user_id in (select id from public.users where email = auth.jwt() ->> 'email'));
create policy "notifications: owner access" on public.notifications
  for all using (user_id in (select id from public.users where email = auth.jwt() ->> 'email'))
  with check (user_id in (select id from public.users where email = auth.jwt() ->> 'email'));
create policy "settings: public read" on public.settings for select using (true);
create policy "logs: insert only" on public.activity_logs for insert with check (true);

-- ---------- Storage buckets (see BUCKETS in src/js/supabase.js) ----------
-- All 8 buckets the code uses, all public (the code reads them via
-- getPublicUrl). This block matches supabase-storage.sql exactly; the full
-- storage access policies live in that file, so run it too if Storage is empty.
insert into storage.buckets (id, name, public) values
  ('screenshots','screenshots', true),
  ('qr-codes','qr-codes', true),
  ('documents','documents', true),
  ('stamps','stamps', true),
  ('signatures','signatures', true),
  ('project-files','project-files', true),
  ('avatars','avatars', true),
  ('demo-templates','demo-templates', true)
on conflict (id) do update set public = excluded.public;

-- ============================================================
-- COMPATIBILITY PATCH (added after code review, 2026-10-15)
-- The schema above provides the general structure, but the code sends some
-- fields with EXACT names. Without these columns, form submission in live mode
-- will fail ("Could not find the 'business' column"):
--   src/js/form.js    -> orders insert: business, "createdAt",
--                        status='demo', plan
--   src/js/payment.js -> orders update: status='screenshot-pending'
--                        -> 'review', coupon, "discountInr", screenshot
--   src/js/admin.js   -> orders update: status='approved',
--                        "approvedAt"
--   src/js/documents.js / tickets -> email se customer identification
-- So these additive columns are added (IF NOT EXISTS — existing data stays safe):
-- ============================================================
alter table public.orders add column if not exists business text default '';
alter table public.orders add column if not exists "createdAt" timestamptz default now();
alter table public.orders add column if not exists "discountInr" numeric default 0;
alter table public.orders add column if not exists screenshot text default '';
alter table public.orders add column if not exists "approvedAt" timestamptz;
alter table public.payments add column if not exists email text default '';
alter table public.tickets add column if not exists email text default '';
alter table public.notifications add column if not exists email text default '';
alter table public.activity_logs add column if not exists "user" text default 'Admin';
alter table public.activity_logs add column if not exists detail text default '';

-- Admin access: the policies above only give owners access to their own orders;
-- the admin needs a separate policy to view/approve ALL orders.
-- This list MUST match ADMIN_EMAILS in src/js/auth.js (the app-side auto-admin
-- list). Fixed 2026-10-16: it previously compared against the placeholder
-- 'admin@example.com', so no real admin could ever pass the RLS admin policies.
create or replace function public.is_admin() returns boolean
language sql stable as $$
  select coalesce(auth.jwt() ->> 'email', '') in
    ('tarzenwebtech@outlook.com', 'mayank999625@gmail.com')
$$;
drop policy if exists "orders: admin all" on public.orders;
create policy "orders: admin all" on public.orders for all using (public.is_admin());
drop policy if exists "payments: admin all" on public.payments;
create policy "payments: admin all" on public.payments for all using (public.is_admin());
drop policy if exists "documents: admin all" on public.documents;
create policy "documents: admin all" on public.documents for all using (public.is_admin());
drop policy if exists "settings: admin write" on public.settings;
create policy "settings: admin write" on public.settings for all using (public.is_admin());
drop policy if exists "screenshots: upload by logged-in" on storage.objects;
create policy "screenshots: upload by logged-in" on storage.objects for insert
  with check (bucket_id = 'screenshots' and auth.role() = 'authenticated');
drop policy if exists "screenshots: admin read" on storage.objects;
create policy "screenshots: admin read" on storage.objects for select
  using (bucket_id = 'screenshots' and public.is_admin());
-- Note: status names stay exactly as the code uses them: demo / screenshot-pending /
-- review / approved / rejected (the names in the comments above were only suggestions).
