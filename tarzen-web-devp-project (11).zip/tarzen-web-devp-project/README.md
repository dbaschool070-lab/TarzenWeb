# Tarzen Web Devp.

SaaS Web Application — Professional website development platform.

Customers fill out an order form → watch a live demo of their category → pay by
UPI QR code → upload their payment screenshot → the admin reviews and approves →
the Bill, Agreement, Receipt and project access are delivered **only inside the
app** (never sent outside it).

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5 + CSS3 + JavaScript |
| Backend | Supabase (Auth + Database + Storage) |
| Auth | Supabase (Email OTP + Google Login) |
| Hosting | Vercel / Netlify |
| Currency | exchangerate-api.com |

---

## Features

- Email OTP + Google Login
- Multi-step order form (3 steps)
- 9 categories with demo websites
- 5-minute demo timer
- QR code payment + screenshot upload
- Admin approval system
- Bill, Agreement, Receipt (A4 + A5)
- Project access + download
- Admin panel with full control
- Dark mode
- Fully responsive

---

## Setup

### 1. Clone / Download

```bash
git clone <your-repo-url>
cd tarzen-web-devp
```

### 2. Install dependencies

```bash
npm install
```

### 3. Configure environment

Copy `.env.example` to `.env` and fill in your Supabase project URL and anon key
(see `SUPABASE-SETUP.md` for the complete go-live guide, including the database
schema, admin email and Email OTP setup).

### 4. Run the app

```bash
npm run dev
```

The app opens at http://localhost:8080 (live-server serves `src/pages`).
