-- Tarzen Web Devp. - GO-LIVE SQL (run ONCE in Supabase: SQL Editor -> New query -> paste this WHOLE file -> Run)
-- Prepared 2026-10-16. This ONE file replaces running supabase-storage.sql and
-- supabase-admin-fix.sql separately on the EXISTING live database.
--
-- What it does (all steps are idempotent - safe to run more than once, it
-- changes no customer/order data):
--   PART A: creates the 8 Storage buckets the app uploads to, all public,
--           and (re)creates their read/write policies.
--   PART B: fixes public.is_admin() - the live database still has the old
--           placeholder 'admin@example.com', so no real admin passes the
--           RLS admin policies. This points it at the two real admin emails,
--           matching ADMIN_EMAILS in src/js/auth.js.
--   PART C: (re)creates the admin RLS policies for orders / payments /
--           documents / settings, plus the admin screenshot read, so the
--           Admin Panel can list and approve other customers' orders.
--   PART D: makes sure the single settings row (id 1) exists.
--
-- Do NOT re-run the full supabase-schema.sql on the live database instead:
-- its base "create policy" statements have no drop-if-exists, so a second
-- run errors out part-way. This file is the safe live-database version.
-- Fresh setups use supabase-schema.sql + supabase-storage.sql as before.

-- ================= PART A: Storage buckets + policies =================
insert into storage.buckets (id, name, public) values
  ('screenshots',    'screenshots',    true),
  ('qr-codes',       'qr-codes',       true),
  ('documents',      'documents',      true),
  ('stamps',         'stamps',         true),
  ('signatures',     'signatures',     true),
  ('project-files',  'project-files',  true),
  ('avatars',        'avatars',        true),
  ('demo-templates', 'demo-templates', true)
on conflict (id) do update set public = excluded.public;

drop policy if exists "tarzen storage public read" on storage.objects;
create policy "tarzen storage public read" on storage.objects
  for select using (bucket_id in ('screenshots','qr-codes','documents','stamps','signatures','project-files','avatars','demo-templates'));

drop policy if exists "tarzen storage auth write" on storage.objects;
create policy "tarzen storage auth write" on storage.objects
  for insert to authenticated with check (bucket_id in ('screenshots','qr-codes','documents','stamps','signatures','project-files','avatars','demo-templates'));

drop policy if exists "tarzen storage auth update" on storage.objects;
create policy "tarzen storage auth update" on storage.objects
  for update to authenticated using (bucket_id in ('screenshots','qr-codes','documents','stamps','signatures','project-files','avatars','demo-templates'));

drop policy if exists "tarzen storage auth delete" on storage.objects;
create policy "tarzen storage auth delete" on storage.objects
  for delete to authenticated using (bucket_id in ('screenshots','qr-codes','documents','stamps','signatures','project-files','avatars','demo-templates'));

-- ================= PART B: real admin check =================
create or replace function public.is_admin() returns boolean
language sql stable as $$
  select coalesce(auth.jwt() ->> 'email', '') in
    ('tarzenwebtech@outlook.com', 'mayank999625@gmail.com')
$$;

-- ================= PART C: admin RLS policies =================
drop policy if exists "orders: admin all" on public.orders;
create policy "orders: admin all" on public.orders for all using (public.is_admin());

drop policy if exists "payments: admin all" on public.payments;
create policy "payments: admin all" on public.payments for all using (public.is_admin());

drop policy if exists "documents: admin all" on public.documents;
create policy "documents: admin all" on public.documents for all using (public.is_admin());

drop policy if exists "settings: admin write" on public.settings;
create policy "settings: admin write" on public.settings for all using (public.is_admin());

drop policy if exists "screenshots: admin read" on storage.objects;
create policy "screenshots: admin read" on storage.objects for select
  using (bucket_id = 'screenshots' and public.is_admin());

-- ================= PART D: settings row =================
insert into public.settings (id) values (1) on conflict (id) do nothing;

-- ================= CHECKS (optional, after running) =================
-- 1) Buckets - must return 8 rows:
--    select id, public from storage.buckets order by id;
-- 2) Admin check: do NOT test is_admin() here in the SQL Editor - it runs
--    without a user login token, so it returns false for everyone. The real
--    test is in the app: log in as admin and confirm the Admin Panel lists
--    ALL customers' orders (not just the admin's own).
