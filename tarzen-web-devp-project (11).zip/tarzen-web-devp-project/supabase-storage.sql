-- Tarzen Web Devp. - Storage buckets (run in Supabase: SQL Editor -> New query -> paste -> Run)
-- Creates every bucket the app uses, with access rules for logged-in users.
-- Safe to run more than once: if a bucket already exists (e.g. created by an
-- older schema with the wrong public/private flag), its flag is corrected.

insert into storage.buckets (id, name, public) values
  ('screenshots',    'screenshots',    true),
  ('qr-codes',       'qr-codes',       true),
  ('documents',      'documents',      true),
  ('stamps',         'stamps',         true),
  ('signatures',     'signatures',     true),
  ('project-files',  'project-files',  true),
  ('avatars',        'avatars',        true),
  ('demo-templates', 'demo-templates', true)
on conflict (id) do update set public = excluded.public;

-- Anyone can view files (the app shows QR codes, documents and project files in-app)
drop policy if exists "tarzen storage public read" on storage.objects;
create policy "tarzen storage public read" on storage.objects
  for select using (bucket_id in ('screenshots','qr-codes','documents','stamps','signatures','project-files','avatars','demo-templates'));

-- Logged-in users can upload / replace / remove files
drop policy if exists "tarzen storage auth write" on storage.objects;
create policy "tarzen storage auth write" on storage.objects
  for insert to authenticated with check (bucket_id in ('screenshots','qr-codes','documents','stamps','signatures','project-files','avatars','demo-templates'));

drop policy if exists "tarzen storage auth update" on storage.objects;
create policy "tarzen storage auth update" on storage.objects
  for update to authenticated using (bucket_id in ('screenshots','qr-codes','documents','stamps','signatures','project-files','avatars','demo-templates'));

drop policy if exists "tarzen storage auth delete" on storage.objects;
create policy "tarzen storage auth delete" on storage.objects
  for delete to authenticated using (bucket_id in ('screenshots','qr-codes','documents','stamps','signatures','project-files','avatars','demo-templates'));
