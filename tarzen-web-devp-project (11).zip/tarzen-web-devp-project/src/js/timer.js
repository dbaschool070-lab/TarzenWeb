/* ============================================
   Tarzen Web Devp. — Timer Utilities
   Countdown, OTP, Demo, Screenshot Timers
   ============================================ */

/* ============================================
   TIMER CLASS
   ============================================ */

export class Timer {
  constructor(options = {}) {
    this.duration = options.duration || 300; // seconds
    this.remaining = this.duration;
    this.interval = null;
    this.isPaused = false;
    this.isRunning = false;
    this.onTick = options.onTick || null;
    this.onComplete = options.onComplete || null;
    this.onStart = options.onStart || null;
    this.onPause = options.onPause || null;
    this.onResume = options.onResume || null;
    this.onStop = options.onStop || null;
    this.storageKey = options.storageKey || null;
    this.autoStart = options.autoStart || false;

    // Restore from storage if available
    if (this.storageKey) {
      this.restore();
    }

    if (this.autoStart) {
      this.start();
    }
  }

  /* ========== START ========== */
  start() {
    if (this.isRunning) return;

    this.isRunning = true;
    this.isPaused = false;

    if (this.onStart) this.onStart(this.remaining);

    this.interval = setInterval(() => {
      if (this.isPaused) return;

      this.remaining--;

      if (this.onTick) this.onTick(this.remaining);

      if (this.storageKey) this.save();

      if (this.remaining <= 0) {
        this.complete();
      }
    }, 1000);
  }

  /* ========== PAUSE ========== */
  pause() {
    if (!this.isRunning || this.isPaused) return;

    this.isPaused = true;
    if (this.onPause) this.onPause(this.remaining);
  }

  /* ========== RESUME ========== */
  resume() {
    if (!this.isRunning || !this.isPaused) return;

    this.isPaused = false;
    if (this.onResume) this.onResume(this.remaining);
  }

  /* ========== STOP ========== */
  stop() {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
    }

    this.isRunning = false;
    this.isPaused = false;

    if (this.onStop) this.onStop(this.remaining);
  }

  /* ========== RESET ========== */
  reset(newDuration) {
    this.stop();
    if (newDuration) this.duration = newDuration;
    this.remaining = this.duration;
    if (this.storageKey) this.clear();
  }

  /* ========== COMPLETE ========== */
  complete() {
    this.stop();
    this.remaining = 0;

    if (this.storageKey) this.clear();

    if (this.onComplete) this.onComplete();
  }

  /* ========== GET REMAINING ========== */
  getRemaining() {
    return this.remaining;
  }

  /* ========== GET FORMATTED ========== */
  getFormatted() {
    return formatTimer(this.remaining);
  }

  /* ========== IS RUNNING ========== */
  isActive() {
    return this.isRunning && !this.isPaused;
  }

  /* ========== SAVE TO STORAGE ========== */
  save() {
    if (!this.storageKey) return;

    try {
      const data = {
        remaining: this.remaining,
        duration: this.duration,
        startedAt: Date.now(),
        isPaused: this.isPaused
      };
      sessionStorage.setItem(this.storageKey, JSON.stringify(data));
    } catch (err) {
      console.error('Timer save error:', err);
    }
  }

  /* ========== RESTORE FROM STORAGE ========== */
  restore() {
    if (!this.storageKey) return;

    try {
      const stored = sessionStorage.getItem(this.storageKey);
      if (!stored) return;

      const data = JSON.parse(stored);
      const elapsed = Math.floor((Date.now() - data.startedAt) / 1000);
      const remaining = Math.max(0, data.remaining - elapsed);

      this.remaining = remaining;
      this.duration = data.duration || this.duration;

      if (remaining <= 0) {
        this.clear();
      }
    } catch (err) {
      console.error('Timer restore error:', err);
    }
  }

  /* ========== CLEAR STORAGE ========== */
  clear() {
    if (this.storageKey) {
      sessionStorage.removeItem(this.storageKey);
    }
  }
}

/* ============================================
   FORMAT TIMER (seconds → MM:SS)
   ============================================ */

export function formatTimer(seconds) {
  if (seconds < 0) seconds = 0;

  const hours = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;

  if (hours > 0) {
    return `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }

  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

/* ============================================
   FORMAT DURATION (human readable)
   ============================================ */

export function formatDuration(seconds) {
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
  return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`;
}

/* ============================================
   OTP TIMER
   ============================================ */

export function createOTPTimer(options = {}) {
  const otpTimer = new Timer({
    duration: options.duration || 300, // 5 minutes
    storageKey: 'otp_timer',
    onTick: options.onTick,
    onComplete: options.onComplete,
    onStart: options.onStart
  });

  return otpTimer;
}

/* ============================================
   RESEND TIMER
   ============================================ */

export function createResendTimer(options = {}) {
  const resendTimer = new Timer({
    duration: options.duration || 30, // 30 seconds
    onTick: options.onTick,
    onComplete: options.onComplete
  });

  return resendTimer;
}

/* ============================================
   DEMO TIMER (5 minutes)
   ============================================ */

export function createDemoTimer(options = {}) {
  const demoTimer = new Timer({
    duration: options.duration || 300, // 5 minutes
    storageKey: 'demo_timer',
    onTick: options.onTick,
    onComplete: options.onComplete,
    onStart: options.onStart,
    onPause: options.onPause,
    onResume: options.onResume
  });

  return demoTimer;
}

/* ============================================
   SCREENSHOT TIMER (10 minutes)
   ============================================ */

export function createScreenshotTimer(options = {}) {
  const screenshotTimer = new Timer({
    duration: options.duration || 600, // 10 minutes
    storageKey: 'screenshot_timer',
    onTick: options.onTick,
    onComplete: options.onComplete,
    onStart: options.onStart
  });

  return screenshotTimer;
}

/* ============================================
   GLOBAL COUNTDOWN
   ============================================ */

export function countdown(seconds, onTick, onComplete) {
  let remaining = seconds;

  if (onTick) onTick(remaining);

  const interval = setInterval(() => {
    remaining--;

    if (onTick) onTick(remaining);

    if (remaining <= 0) {
      clearInterval(interval);
      if (onComplete) onComplete();
    }
  }, 1000);

  return {
    stop: () => clearInterval(interval),
    getRemaining: () => remaining
  };
}

/* ============================================
   WAIT / DELAY
   ============================================ */

export function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/* ============================================
   THROTTLE TIMER
   ============================================ */

export function throttleTimer(callback, delay = 1000) {
  let lastCall = 0;

  return function (...args) {
    const now = Date.now();
    if (now - lastCall >= delay) {
      lastCall = now;
      callback(...args);
    }
  };
}

/* ============================================
   DEBOUNCE TIMER
   ============================================ */

export function debounceTimer(callback, delay = 300) {
  let timeout;

  return function (...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => callback(...args), delay);
  };
}

/* ============================================
   INTERVAL MANAGER
   ============================================ */

export class IntervalManager {
  constructor() {
    this.intervals = new Map();
  }

  add(key, callback, delay) {
    this.remove(key);

    const id = setInterval(callback, delay);
    this.intervals.set(key, id);
    return id;
  }

  remove(key) {
    if (this.intervals.has(key)) {
      clearInterval(this.intervals.get(key));
      this.intervals.delete(key);
    }
  }

  clearAll() {
    this.intervals.forEach(id => clearInterval(id));
    this.intervals.clear();
  }

  has(key) {
    return this.intervals.has(key);
  }
}

/* ============================================
   TIME AGO
   ============================================ */

export function timeAgo(date) {
  const seconds = Math.floor((Date.now() - new Date(date).getTime()) / 1000);

  if (seconds < 60) return 'Just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;

  return new Date(date).toLocaleDateString('en-IN');
}

/* ============================================
   TIME UNTIL
   ============================================ */

export function timeUntil(date) {
  const target = new Date(date).getTime();
  const now = Date.now();
  const diff = target - now;

  if (diff <= 0) return 'Expired';

  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) return `${days}d ${hours % 24}h`;
  if (hours > 0) return `${hours}h ${minutes % 60}m`;
  if (minutes > 0) return `${minutes}m ${seconds % 60}s`;

  return `${seconds}s`;
}

/* ============================================
   CURRENT TIMESTAMP
   ============================================ */

export function now() {
  return new Date().toISOString();
}

/* ============================================
   TIMER PRESETS
   ============================================ */

export const TIMER_PRESETS = {
  OTP: 300,           // 5 minutes
  RESEND: 30,         // 30 seconds
  DEMO: 300,          // 5 minutes
  SCREENSHOT: 600,    // 10 minutes
  SESSION: 3600,      // 1 hour
  AUTO_SAVE: 10,      // 10 seconds
  APPROVAL: 86400     // 24 hours
};

/* ============================================
   AUTO SAVE TIMER
   ============================================ */

export function createAutoSaveTimer(callback, interval = 10000) {
  let timerId = null;

  return {
    start: () => {
      if (timerId) return;
      timerId = setInterval(callback, interval);
    },
    stop: () => {
      if (timerId) {
        clearInterval(timerId);
        timerId = null;
      }
    },
    isRunning: () => timerId !== null
  };
}

/* ============================================
   EXPORT DEFAULT
   ============================================ */

export default {
  Timer,
  formatTimer,
  formatDuration,
  createOTPTimer,
  createResendTimer,
  createDemoTimer,
  createScreenshotTimer,
  countdown,
  wait,
  throttleTimer,
  debounceTimer,
  IntervalManager,
  timeAgo,
  timeUntil,
  now,
  TIMER_PRESETS,
  createAutoSaveTimer
};