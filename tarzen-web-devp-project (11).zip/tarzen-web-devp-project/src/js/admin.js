/* ============================================
   Tarzen Web Devp. — Admin Panel
   Orders, Payments, Pricing, QR, Company, Customers
   ============================================ */

import {
  supabase,
  TABLES,
  BUCKETS,
  ORDER_STATUS,
  PAYMENT_STATUS,
  USER_ROLES,
  logActivity
} from './supabase.js';
import { getCurrentUser, getUserProfile } from './auth.js';
import {
  showToast,
  showLoading,
  hideLoading,
  formatCurrency,
  formatDate,
  timeAgo,
  formatFileSize,
  generateOrderId,
  confirmDialog,
  getQueryParam
} from './app.js';

/* ============================================
   ADMIN STATE
   ============================================ */

let currentAdmin = null;
let orders = [];
let filteredOrders = [];
let currentPage = 1;
const perPage = 10;
let selectedOrders = new Set();

/* ============================================
   INIT ADMIN
   ============================================ */

export async function initAdmin() {
  const user = await getCurrentUser();
  if (!user) {
    window.location.href = 'login.html';
    return;
  }

  const profile = await getUserProfile(user.id);
  if (!profile || (profile.role !== USER_ROLES.ADMIN && profile.role !== USER_ROLES.SUPER_ADMIN)) {
    showToast('Access denied. Admin only.', 'danger');
    setTimeout(() => window.location.href = '../dashboard.html', 1500);
    return;
  }

  currentAdmin = { ...user, ...profile };

  // Route based on page
  const page = detectAdminPage();

  switch (page) {
    case 'dashboard':
      await initAdminDashboard();
      break;
    case 'orders':
      await initAdminOrders();
      break;
    case 'order-detail':
      await initOrderDetail();
      break;
    case 'payments':
      await initAdminPayments();
      break;
    case 'pricing':
      await initAdminPricing();
      break;
    case 'discounts':
      await initAdminDiscounts();
      break;
    case 'qr':
      await initAdminQR();
      break;
    case 'company':
      await initAdminCompany();
      break;
    case 'customers':
      await initAdminCustomers();
      break;
    case 'analytics':
      await initAdminAnalytics();
      break;
    default:
      console.log('Admin page:', page);
  }
}

function detectAdminPage() {
  const path = window.location.pathname;
  if (path.includes('order-detail')) return 'order-detail';
  if (path.includes('orders')) return 'orders';
  if (path.includes('payments')) return 'payments';
  if (path.includes('pricing')) return 'pricing';
  if (path.includes('discounts')) return 'discounts';
  if (path.includes('qr')) return 'qr';
  if (path.includes('company')) return 'company';
  if (path.includes('customers')) return 'customers';
  if (path.includes('analytics')) return 'analytics';
  return 'dashboard';
}

/* ============================================
   ADMIN DASHBOARD
   ============================================ */

async function initAdminDashboard() {
  await loadDashboardStats();
  await loadRecentOrders();
  await loadPendingApprovals();
}

async function loadDashboardStats() {
  try {
    // Total orders
    const { count: totalOrders } = await supabase
      .from(TABLES.ORDERS)
      .select('*', { count: 'exact', head: true });

    // Pending orders
    const { count: pendingOrders } = await supabase
      .from(TABLES.ORDERS)
      .select('*', { count: 'exact', head: true })
      .in('status', [ORDER_STATUS.SCREENSHOT_UPLOADED, ORDER_STATUS.ADMIN_REVIEW]);

    // Approved orders
    const { count: approvedOrders } = await supabase
      .from(TABLES.ORDERS)
      .select('*', { count: 'exact', head: true })
      .eq('status', ORDER_STATUS.APPROVED);

    // Total customers
    const { count: totalCustomers } = await supabase
      .from(TABLES.USERS)
      .select('*', { count: 'exact', head: true })
      .eq('role', USER_ROLES.CUSTOMER);

    // Revenue
    const { data: revenueData } = await supabase
      .from(TABLES.ORDERS)
      .select('final_amount')
      .eq('status', ORDER_STATUS.APPROVED);

    const totalRevenue = revenueData?.reduce((sum, o) => sum + (o.final_amount || 0), 0) || 0;

    updateStat('statTotalOrders', totalOrders || 0);
    updateStat('statPendingOrders', pendingOrders || 0);
    updateStat('statApprovedOrders', approvedOrders || 0);
    updateStat('statCustomers', totalCustomers || 0);
    updateStat('statRevenue', formatCurrency(totalRevenue, 'INR'));
  } catch (err) {
    console.error('Stats error:', err);
  }
}

function updateStat(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

async function loadRecentOrders() {
  const { data, error } = await supabase
    .from(TABLES.ORDERS)
    .select('*')
    .order('created_at', { ascending: false })
    .limit(10);

  if (error) {
    console.error('Recent orders error:', error);
    return;
  }

  const container = document.getElementById('recentOrdersList');
  if (!container) return;

  if (!data || data.length === 0) {
    container.innerHTML = '<div class="empty-state"><p>No orders yet</p></div>';
    return;
  }

  container.innerHTML = data.map(order => `
    <div class="order-item" onclick="window.location.href='order-detail.html?id=${order.id}'">
      <div class="order-item-icon">📦</div>
      <div class="order-item-info">
        <div class="order-item-title">${order.category}</div>
        <div class="order-item-meta">${order.id} · ${timeAgo(order.created_at)}</div>
      </div>
      <div class="order-item-right">
        <span class="order-status ${order.status}">${formatStatus(order.status)}</span>
      </div>
    </div>
  `).join('');
}

async function loadPendingApprovals() {
  const { data, error } = await supabase
    .from(TABLES.ORDERS)
    .select('*')
    .in('status', [ORDER_STATUS.SCREENSHOT_UPLOADED, ORDER_STATUS.ADMIN_REVIEW])
    .order('created_at', { ascending: true })
    .limit(5);

  if (error) return;

  const container = document.getElementById('pendingApprovals');
  if (!container) return;

  if (!data || data.length === 0) {
    container.innerHTML = '<p class="text-gray" style="padding: 16px;">No pending approvals 🎉</p>';
    return;
  }

  container.innerHTML = data.map(order => `
    <div class="order-item" onclick="window.location.href='order-detail.html?id=${order.id}'">
      <div class="order-item-icon">⏳</div>
      <div class="order-item-info">
        <div class="order-item-title">${order.category}</div>
        <div class="order-item-meta">${order.id}</div>
      </div>
      <div class="order-item-right">
        <span class="order-status ${order.status}">${formatStatus(order.status)}</span>
      </div>
    </div>
  `).join('');
}

/* ============================================
   ADMIN ORDERS LIST
   ============================================ */

async function initAdminOrders() {
  await loadOrders();
  setupOrderFilters();
  setupBulkActions();
}

async function loadOrders() {
  const { data, error } = await supabase
    .from(TABLES.ORDERS)
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Orders error:', error);
    showToast('Failed to load orders', 'danger');
    return;
  }

  orders = data || [];
  filteredOrders = [...orders];
  renderOrders();
}

function setupOrderFilters() {
  const searchInput = document.getElementById('orderSearch');
  const statusFilter = document.getElementById('statusFilter');
  const categoryFilter = document.getElementById('categoryFilter');

  const applyFilters = () => {
    const search = searchInput?.value.toLowerCase() || '';
    const status = statusFilter?.value || '';
    const category = categoryFilter?.value || '';

    filteredOrders = orders.filter(o => {
      const matchesSearch = !search ||
        o.id.toLowerCase().includes(search) ||
        o.category.toLowerCase().includes(search);
      const matchesStatus = !status || o.status === status;
      const matchesCategory = !category || o.category === category;
      return matchesSearch && matchesStatus && matchesCategory;
    });

    currentPage = 1;
    renderOrders();
  };

  searchInput?.addEventListener('input', applyFilters);
  statusFilter?.addEventListener('change', applyFilters);
  categoryFilter?.addEventListener('change', applyFilters);
}

function renderOrders() {
  const tbody = document.getElementById('ordersTableBody');
  if (!tbody) return;

  const start = (currentPage - 1) * perPage;
  const paginated = filteredOrders.slice(start, start + perPage);

  if (paginated.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding: 40px;">No orders found</td></tr>';
    return;
  }

  tbody.innerHTML = paginated.map(order => `
    <tr>
      <td>
        <input type="checkbox" class="order-checkbox" data-id="${order.id}" ${selectedOrders.has(order.id) ? 'checked' : ''}>
      </td>
      <td><strong>${order.id}</strong></td>
      <td>${order.category}</td>
      <td>${formatCurrency(order.final_amount || order.amount || 0, 'INR')}</td>
      <td><span class="order-status ${order.status}">${formatStatus(order.status)}</span></td>
      <td>${formatDate(order.created_at)}</td>
      <td>
        <div class="actions">
          <a href="order-detail.html?id=${order.id}" class="btn btn-sm btn-outline">View</a>
        </div>
      </td>
    </tr>
  `).join('');

  // Checkbox listeners
  tbody.querySelectorAll('.order-checkbox').forEach(cb => {
    cb.addEventListener('change', (e) => {
      const id = e.target.dataset.id;
      if (e.target.checked) selectedOrders.add(id);
      else selectedOrders.delete(id);
      updateBulkActions();
    });
  });

  renderPagination();
}

function renderPagination() {
  const totalPages = Math.ceil(filteredOrders.length / perPage);
  const container = document.getElementById('ordersPagination');
  if (!container) return;

  if (totalPages <= 1) {
    container.innerHTML = '';
    return;
  }

  let html = '<div class="admin-pagination-controls">';
  for (let i = 1; i <= totalPages; i++) {
    html += `<button class="admin-pagination-btn ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</button>`;
  }
  html += '</div>';

  container.innerHTML = html;

  container.querySelectorAll('[data-page]').forEach(btn => {
    btn.addEventListener('click', () => {
      currentPage = parseInt(btn.dataset.page);
      renderOrders();
    });
  });
}

/* ============================================
   BULK ACTIONS
   ============================================ */

function setupBulkActions() {
  const selectAll = document.getElementById('selectAll');
  const bulkApprove = document.getElementById('bulkApprove');
  const bulkReject = document.getElementById('bulkReject');

  selectAll?.addEventListener('change', (e) => {
    const checkboxes = document.querySelectorAll('.order-checkbox');
    checkboxes.forEach(cb => {
      cb.checked = e.target.checked;
      const id = cb.dataset.id;
      if (e.target.checked) selectedOrders.add(id);
      else selectedOrders.delete(id);
    });
    updateBulkActions();
  });

  bulkApprove?.addEventListener('click', async () => {
    if (selectedOrders.size === 0) return;
    const confirmed = await confirmDialog(`Approve ${selectedOrders.size} orders?`, 'Bulk Approve');
    if (!confirmed) return;

    showLoading(bulkApprove);
    await bulkUpdateStatus([...selectedOrders], ORDER_STATUS.APPROVED);
    hideLoading(bulkApprove);
    selectedOrders.clear();
    await loadOrders();
  });

  bulkReject?.addEventListener('click', async () => {
    if (selectedOrders.size === 0) return;
    const confirmed = await confirmDialog(`Reject ${selectedOrders.size} orders?`, 'Bulk Reject');
    if (!confirmed) return;

    showLoading(bulkReject);
    await bulkUpdateStatus([...selectedOrders], ORDER_STATUS.REJECTED);
    hideLoading(bulkReject);
    selectedOrders.clear();
    await loadOrders();
  });
}

function updateBulkActions() {
  const bar = document.getElementById('bulkActionsBar');
  const count = document.getElementById('selectedCount');

  if (bar) {
    bar.style.display = selectedOrders.size > 0 ? 'flex' : 'none';
  }
  if (count) {
    count.textContent = selectedOrders.size;
  }
}

async function bulkUpdateStatus(ids, status) {
  try {
    const { error } = await supabase
      .from(TABLES.ORDERS)
      .update({ status })
      .in('id', ids);

    if (error) throw error;

    await logActivity(currentAdmin.id, 'bulk_status_update', { ids, status });
    showToast(`${ids.length} orders updated`, 'success');
  } catch (err) {
    console.error('Bulk update error:', err);
    showToast('Failed to update orders', 'danger');
  }
}

/* ============================================
   ORDER DETAIL
   ============================================ */

async function initOrderDetail() {
  const id = getQueryParam('id');
  if (!id) {
    showToast('Order not found', 'danger');
    window.location.href = 'orders.html';
    return;
  }

  await loadOrderDetail(id);
  setupOrderDetailActions(id);
}

async function loadOrderDetail(orderId) {
  const { data: order, error } = await supabase
    .from(TABLES.ORDERS)
    .select('*')
    .eq('id', orderId)
    .single();

  if (error || !order) {
    showToast('Order not found', 'danger');
    window.location.href = 'orders.html';
    return;
  }

  // Form data
  const { data: form } = await supabase
    .from(TABLES.FORM_DATA)
    .select('*')
    .eq('order_id', orderId)
    .single();

  // Payment
  const { data: payment } = await supabase
    .from(TABLES.PAYMENTS)
    .select('*')
    .eq('order_id', orderId)
    .order('created_at', { ascending: false })
    .limit(1)
    .single();

  renderOrderDetail(order, form, payment);
}

function renderOrderDetail(order, form, payment) {
  // Order info
  setText('detailOrderId', order.id);
  setText('detailCategory', order.category);
  setText('detailStatus', formatStatus(order.status));
  setText('detailCreated', formatDate(order.created_at, 'datetime'));
  setText('detailAmount', formatCurrency(order.final_amount || order.amount || 0, 'INR'));

  // Customer
  if (form) {
    setText('detailName', form.name);
    setText('detailEmail', form.email);
    setText('detailPhone', form.phone || '-');
    setText('detailBusiness', form.business_name);
    setText('detailAddress', `${form.address || ''}, ${form.city || ''}`);
    setText('detailGST', form.gst || '-');
  }

  // Payment screenshot
  if (payment && payment.screenshot_url) {
    loadScreenshot(payment.screenshot_url);
  } else {
    const preview = document.getElementById('screenshotPreview');
    if (preview) preview.innerHTML = '<p class="text-gray">No screenshot uploaded</p>';
  }

  // Status badge
  const statusEl = document.getElementById('detailStatusBadge');
  if (statusEl) {
    statusEl.className = `order-status ${order.status}`;
    statusEl.textContent = formatStatus(order.status);
  }
}

async function loadScreenshot(filePath) {
  try {
    const { data } = await supabase.storage
      .from(BUCKETS.SCREENSHOTS)
      .createSignedUrl(filePath, 3600);

    const img = document.getElementById('screenshotImage');
    if (img && data) {
      img.src = data.signedUrl;
      img.onclick = () => window.open(data.signedUrl, '_blank');
    }
  } catch (err) {
    console.error('Screenshot error:', err);
  }
}

function setupOrderDetailActions(orderId) {
  const approveBtn = document.getElementById('approveOrder');
  const rejectBtn = document.getElementById('rejectOrder');
  const discountInput = document.getElementById('discountPercent');
  const applyDiscountBtn = document.getElementById('applyDiscount');
  const saveNoteBtn = document.getElementById('saveNote');

  approveBtn?.addEventListener('click', async () => {
    const confirmed = await confirmDialog('Approve this order?', 'Approve');
    if (!confirmed) return;

    showLoading(approveBtn);
    await updateOrderStatus(orderId, ORDER_STATUS.APPROVED);
    hideLoading(approveBtn);
    setTimeout(() => window.location.href = 'orders.html', 1000);
  });

  rejectBtn?.addEventListener('click', async () => {
    const reason = prompt('Reason for rejection:');
    if (!reason) return;

    showLoading(rejectBtn);
    await updateOrderStatus(orderId, ORDER_STATUS.REJECTED);
    await logActivity(currentAdmin.id, 'order_rejected', { order_id: orderId, reason });
    hideLoading(rejectBtn);
    setTimeout(() => window.location.href = 'orders.html', 1000);
  });

  applyDiscountBtn?.addEventListener('click', async () => {
    const percent = parseFloat(discountInput?.value || '0');
    if (percent < 0 || percent > 100) {
      showToast('Discount must be 0-100', 'warning');
      return;
    }

    await applyDiscount(orderId, percent);
  });

  saveNoteBtn?.addEventListener('click', async () => {
    const note = document.getElementById('adminNote')?.value;
    if (!note) return;

    await logActivity(currentAdmin.id, 'order_note', { order_id: orderId, note });
    showToast('Note saved', 'success');
  });
}

async function updateOrderStatus(orderId, status) {
  try {
    const { error } = await supabase
      .from(TABLES.ORDERS)
      .update({
        status,
        updated_at: new Date().toISOString()
      })
      .eq('id', orderId);

    if (error) throw error;

    await logActivity(currentAdmin.id, 'order_status_update', { order_id: orderId, status });
    showToast(`Order ${status}`, 'success');
  } catch (err) {
    console.error('Status update error:', err);
    showToast('Failed to update order', 'danger');
  }
}

async function applyDiscount(orderId, percent) {
  try {
    // Get order
    const { data: order } = await supabase
      .from(TABLES.ORDERS)
      .select('amount')
      .eq('id', orderId)
      .single();

    if (!order) throw new Error('Order not found');

    const discount = (order.amount * percent) / 100;
    const finalAmount = order.amount - discount;

    const { error } = await supabase
      .from(TABLES.ORDERS)
      .update({
        discount,
        final_amount: finalAmount
      })
      .eq('id', orderId);

    if (error) throw error;

    await logActivity(currentAdmin.id, 'discount_applied', { order_id: orderId, percent });
    showToast(`${percent}% discount applied`, 'success');

    setTimeout(() => window.location.reload(), 1000);
  } catch (err) {
    console.error('Discount error:', err);
    showToast('Failed to apply discount', 'danger');
  }
}

/* ============================================
   ADMIN PAYMENTS
   ============================================ */

async function initAdminPayments() {
  const { data, error } = await supabase
    .from(TABLES.PAYMENTS)
    .select('*')
    .order('created_at', { ascending: false });

  if (error) return;

  const tbody = document.getElementById('paymentsTableBody');
  if (!tbody) return;

  if (!data || data.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 40px;">No payments</td></tr>';
    return;
  }

  tbody.innerHTML = data.map(p => `
    <tr>
      <td>${p.order_id}</td>
      <td>${formatCurrency(p.amount || 0, 'INR')}</td>
      <td><span class="order-status ${p.status}">${p.status}</span></td>
      <td>${p.coupon_code || '-'}</td>
      <td>${formatDate(p.created_at)}</td>
      <td>
        <div class="actions">
          <button class="btn btn-sm btn-success" onclick="approvePayment('${p.id}')">Verify</button>
          <button class="btn btn-sm btn-danger" onclick="rejectPayment('${p.id}')">Reject</button>
        </div>
      </td>
    </tr>
  `).join('');
}

window.approvePayment = async (paymentId) => {
  try {
    await supabase
      .from(TABLES.PAYMENTS)
      .update({ status: PAYMENT_STATUS.VERIFIED, approved_at: new Date().toISOString(), approved_by: currentAdmin.id })
      .eq('id', paymentId);

    showToast('Payment verified', 'success');
    setTimeout(() => window.location.reload(), 1000);
  } catch (err) {
    showToast('Failed', 'danger');
  }
};

window.rejectPayment = async (paymentId) => {
  try {
    await supabase
      .from(TABLES.PAYMENTS)
      .update({ status: PAYMENT_STATUS.REJECTED })
      .eq('id', paymentId);

    showToast('Payment rejected', 'info');
    setTimeout(() => window.location.reload(), 1000);
  } catch (err) {
    showToast('Failed', 'danger');
  }
};

/* ============================================
   ADMIN PRICING
   ============================================ */

async function initAdminPricing() {
  const { data } = await supabase
    .from(TABLES.SETTINGS)
    .select('value')
    .eq('key', 'pricing')
    .single();

  const pricing = data?.value || {};

  setValue('priceMonthlyUSD', pricing.monthly?.usd || 20);
  setValue('priceMonthlyINR', pricing.monthly?.inr || 1650);
  setValue('priceYearlyUSD', pricing.yearly?.usd || 216);
  setValue('priceYearlyINR', pricing.yearly?.inr || 18000);
  setValue('priceOneTimeUSD', pricing.one_time?.usd || 500);
  setValue('priceOneTimeINR', pricing.one_time?.inr || 41500);
  setValue('priceWithCodeUSD', pricing.with_code?.usd || 1550);
  setValue('priceWithCodeINR', pricing.with_code?.inr || 128000);
  setValue('priceMaintenanceUSD', pricing.maintenance?.usd || 10);
  setValue('priceMaintenanceINR', pricing.maintenance?.inr || 825);
  setValue('gstPercent', pricing.gst || 18);

  const saveBtn = document.getElementById('savePricing');
  saveBtn?.addEventListener('click', savePricing);
}

async function savePricing() {
  const pricing = {
    monthly: { usd: getValue('priceMonthlyUSD'), inr: getValue('priceMonthlyINR') },
    yearly: { usd: getValue('priceYearlyUSD'), inr: getValue('priceYearlyINR') },
    one_time: { usd: getValue('priceOneTimeUSD'), inr: getValue('priceOneTimeINR') },
    with_code: { usd: getValue('priceWithCodeUSD'), inr: getValue('priceWithCodeINR') },
    maintenance: { usd: getValue('priceMaintenanceUSD'), inr: getValue('priceMaintenanceINR') },
    gst: getValue('gstPercent')
  };

  try {
    const { error } = await supabase
      .from(TABLES.SETTINGS)
      .upsert({ key: 'pricing', value: pricing }, { onConflict: 'key' });

    if (error) throw error;

    await logActivity(currentAdmin.id, 'pricing_updated', pricing);
    showToast('Pricing updated!', 'success');
  } catch (err) {
    console.error('Pricing save error:', err);
    showToast('Failed to save pricing', 'danger');
  }
}

/* ============================================
   ADMIN DISCOUNTS
   ============================================ */

async function initAdminDiscounts() {
  await loadDiscounts();

  const form = document.getElementById('discountForm');
  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    await createDiscount();
  });
}

async function loadDiscounts() {
  const { data } = await supabase
    .from(TABLES.DISCOUNTS)
    .select('*')
    .order('created_at', { ascending: false });

  const tbody = document.getElementById('discountsTableBody');
  if (!tbody) return;

  if (!data || data.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 40px;">No discounts</td></tr>';
    return;
  }

  tbody.innerHTML = data.map(d => `
    <tr>
      <td><strong>${d.code}</strong></td>
      <td>${d.type}</td>
      <td>${d.value}${d.type === 'percentage' ? '%' : '₹'}</td>
      <td>${d.expiry ? formatDate(d.expiry) : '-'}</td>
      <td>${d.used_count || 0}/${d.usage_limit || '∞'}</td>
      <td>
        <button class="btn btn-sm btn-danger" onclick="deleteDiscount('${d.id}')">Delete</button>
      </td>
    </tr>
  `).join('');
}

async function createDiscount() {
  const code = document.getElementById('discountCode')?.value.toUpperCase();
  const type = document.getElementById('discountType')?.value;
  const value = parseFloat(document.getElementById('discountValue')?.value);
  const expiry = document.getElementById('discountExpiry')?.value;
  const limit = parseInt(document.getElementById('discountLimit')?.value) || null;

  if (!code || !value) {
    showToast('Code and value required', 'warning');
    return;
  }

  try {
    const { error } = await supabase
      .from(TABLES.DISCOUNTS)
      .insert({
        code,
        type,
        value,
        expiry: expiry || null,
        usage_limit: limit,
        used_count: 0,
        created_at: new Date().toISOString()
      });

    if (error) throw error;

    showToast('Discount created!', 'success');
    document.getElementById('discountForm').reset();
    await loadDiscounts();
  } catch (err) {
    console.error('Discount create error:', err);
    showToast('Failed to create discount', 'danger');
  }
}

window.deleteDiscount = async (id) => {
  const confirmed = await confirmDialog('Delete this discount?', 'Delete');
  if (!confirmed) return;

  await supabase.from(TABLES.DISCOUNTS).delete().eq('id', id);
  showToast('Deleted', 'success');
  await loadDiscounts();
};

/* ============================================
   ADMIN QR CODE
   ============================================ */

async function initAdminQR() {
  await loadCurrentQR();

  const uploadBtn = document.getElementById('uploadQR');
  const fileInput = document.getElementById('qrFile');

  uploadBtn?.addEventListener('click', () => fileInput?.click());
  fileInput?.addEventListener('change', handleQRUpload);
}

async function loadCurrentQR() {
  const { data } = await supabase
    .from(TABLES.SETTINGS)
    .select('value')
    .eq('key', 'qr_code')
    .single();

  const img = document.getElementById('currentQR');
  if (img && data?.value) {
    img.src = data.value.url || data.value;
    img.style.display = 'block';
  }
}

async function handleQRUpload(e) {
  const file = e.target.files[0];
  if (!file) return;

  if (!file.type.startsWith('image/')) {
    showToast('Please upload an image', 'warning');
    return;
  }

  try {
    const fileName = `qr_${Date.now()}_${file.name}`;
    const { error: uploadError } = await supabase.storage
      .from(BUCKETS.QR_CODES)
      .upload(fileName, file, { upsert: true });

    if (uploadError) throw uploadError;

    const { data: urlData } = supabase.storage
      .from(BUCKETS.QR_CODES)
      .getPublicUrl(fileName);

    const qrUrl = urlData.publicUrl;

    await supabase
      .from(TABLES.SETTINGS)
      .upsert({ key: 'qr_code', value: { url: qrUrl } }, { onConflict: 'key' });

    showToast('QR code updated!', 'success');
    await loadCurrentQR();
  } catch (err) {
    console.error('QR upload error:', err);
    showToast('Failed to upload QR', 'danger');
  }
}

/* ============================================
   ADMIN COMPANY
   ============================================ */

async function initAdminCompany() {
  const { data } = await supabase
    .from(TABLES.SETTINGS)
    .select('value')
    .eq('key', 'company')
    .single();

  const company = data?.value || {};

  setValue('companyName', company.name || 'Tarzen Web Devp.');
  setValue('companyAddress', company.address || '');
  setValue('companyGST', company.gst || '');
  setValue('companyPhone', company.phone || '');
  setValue('companyEmail', company.email || '');

  const saveBtn = document.getElementById('saveCompany');
  saveBtn?.addEventListener('click', saveCompany);

  setupImageUpload('logoFile', 'logoPreview', 'logo');
  setupImageUpload('stampFile', 'stampPreview', 'stamp');
  setupImageUpload('signatureFile', 'signaturePreview', 'signature');
}

function setupImageUpload(inputId, previewId, key) {
  const input = document.getElementById(inputId);
  const preview = document.getElementById(previewId);

  input?.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      const fileName = `${key}_${Date.now()}_${file.name}`;
      const bucket = key === 'logo' ? BUCKETS.DOCUMENTS : (key === 'stamp' ? BUCKETS.STAMPS : BUCKETS.SIGNATURES);

      const { error } = await supabase.storage
        .from(bucket)
        .upload(fileName, file, { upsert: true });

      if (error) throw error;

      const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(fileName);

      if (preview) {
        preview.src = urlData.publicUrl;
        preview.style.display = 'block';
      }

      // Save to company settings
      const { data: current } = await supabase
        .from(TABLES.SETTINGS)
        .select('value')
        .eq('key', 'company')
        .single();

      const company = current?.value || {};
      company[key] = urlData.publicUrl;

      await supabase
        .from(TABLES.SETTINGS)
        .upsert({ key: 'company', value: company }, { onConflict: 'key' });

      showToast(`${key} uploaded!`, 'success');
    } catch (err) {
      console.error('Upload error:', err);
      showToast('Upload failed', 'danger');
    }
  });
}

async function saveCompany() {
  const company = {
    name: getValue('companyName'),
    address: getValue('companyAddress'),
    gst: getValue('companyGST'),
    phone: getValue('companyPhone'),
    email: getValue('companyEmail')
  };

  try {
    const { data: current } = await supabase
      .from(TABLES.SETTINGS)
      .select('value')
      .eq('key', 'company')
      .single();

    const merged = { ...(current?.value || {}), ...company };

    await supabase
      .from(TABLES.SETTINGS)
      .upsert({ key: 'company', value: merged }, { onConflict: 'key' });

    showToast('Company details saved!', 'success');
  } catch (err) {
    console.error('Save error:', err);
    showToast('Failed to save', 'danger');
  }
}

/* ============================================
   ADMIN CUSTOMERS
   ============================================ */

async function initAdminCustomers() {
  const { data, error } = await supabase
    .from(TABLES.USERS)
    .select('*')
    .eq('role', USER_ROLES.CUSTOMER)
    .order('created_at', { ascending: false });

  if (error) return;

  const tbody = document.getElementById('customersTableBody');
  if (!tbody) return;

  if (!data || data.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding: 40px;">No customers</td></tr>';
    return;
  }

  tbody.innerHTML = data.map(c => `
    <tr>
      <td><strong>${c.name || '-'}</strong></td>
      <td>${c.email}</td>
      <td>${c.phone || '-'}</td>
      <td>${formatDate(c.created_at)}</td>
      <td>
        <span class="badge badge-primary">${c.role}</span>
      </td>
    </tr>
  `).join('');
}

/* ============================================
   ADMIN ANALYTICS
   ============================================ */

async function initAdminAnalytics() {
  const { data: orders } = await supabase
    .from(TABLES.ORDERS)
    .select('*');

  if (!orders) return;

  // Revenue by month
  const revenueByMonth = {};
  orders.forEach(o => {
    if (o.status === ORDER_STATUS.APPROVED) {
      const month = new Date(o.created_at).toLocaleDateString('en-IN', { month: 'short', year: 'numeric' });
      revenueByMonth[month] = (revenueByMonth[month] || 0) + (o.final_amount || 0);
    }
  });

  // Orders by category
  const ordersByCategory = {};
  orders.forEach(o => {
    ordersByCategory[o.category] = (ordersByCategory[o.category] || 0) + 1;
  });

  renderAnalytics(revenueByMonth, ordersByCategory);
}

function renderAnalytics(revenue, categories) {
  const container = document.getElementById('analyticsContent');
  if (!container) return;

  container.innerHTML = `
    <div class="admin-card">
      <div class="admin-card-header">
        <h3>Revenue by Month</h3>
      </div>
      <div class="admin-card-body">
        ${Object.entries(revenue).map(([month, amount]) => `
          <div class="order-detail-row">
            <span>${month}</span>
            <strong>${formatCurrency(amount, 'INR')}</strong>
          </div>
        `).join('') || '<p>No data</p>'}
      </div>
    </div>

    <div class="admin-card" style="margin-top: 24px;">
      <div class="admin-card-header">
        <h3>Orders by Category</h3>
      </div>
      <div class="admin-card-body">
        ${Object.entries(categories).map(([cat, count]) => `
          <div class="order-detail-row">
            <span>${cat}</span>
            <strong>${count} orders</strong>
          </div>
        `).join('') || '<p>No data</p>'}
      </div>
    </div>
  `;
}

/* ============================================
   HELPERS
   ============================================ */

function setText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

function setValue(id, value) {
  const el = document.getElementById(id);
  if (el) el.value = value;
}

function getValue(id) {
  const el = document.getElementById(id);
  return el ? el.value : '';
}

function formatStatus(status) {
  return status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
}

/* ============================================
   ADMIN LOGOUT
   ============================================ */

export async function adminLogout() {
  await supabase.auth.signOut();
  window.location.href = '../login.html';
}

/* ============================================
   AUTO-INIT
   ============================================ */

if (document.querySelector('.admin')) {
  document.addEventListener('DOMContentLoaded', initAdmin);
}

/* ============================================
   EXPORT DEFAULT
   ============================================ */

export default {
  initAdmin,
  adminLogout
};