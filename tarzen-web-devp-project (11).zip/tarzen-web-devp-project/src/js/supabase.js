/* ============================================
   Tarzen Web Devp. — Supabase Client
   Database, Auth, Storage Connection
   ============================================ */

import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

/* ============================================
   CONFIGURATION
   ============================================ */

const SUPABASE_URL = 'https://sjpwsawdkmkcgzfcjppz.supabase.co';

const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNqcHdzYXdka21rY2d6ZmNqcHB6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTIwNzEwMTIsImV4cCI6MjEwNzY0NzAxMn0.NK8yABOe-4MzJbVs9dK3ijspVP9fy8Cc_XkTa_xDSCY';

/* ============================================
   SUPABASE CLIENT
   ============================================ */

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    storage: window.localStorage,
    storageKey: 'tarzen-auth-token',
    flowType: 'pkce'
  },
  global: {
    headers: {
      'x-application-name': 'tarzen-web-devp'
    }
  },
  db: {
    schema: 'public'
  },
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  }
});

/* ============================================
   DATABASE TABLES
   ============================================ */

export const TABLES = {
  USERS: 'users',
  ORDERS: 'orders',
  FORM_DATA: 'form_data',
  PAYMENTS: 'payments',
  DOCUMENTS: 'documents',
  SETTINGS: 'settings',
  DISCOUNTS: 'discounts',
  NOTIFICATIONS: 'notifications',
  TICKETS: 'tickets',
  ACTIVITY_LOGS: 'activity_logs'
};

/* ============================================
   STORAGE BUCKETS
   ============================================ */

export const BUCKETS = {
  SCREENSHOTS: 'screenshots',
  QR_CODES: 'qr-codes',
  DOCUMENTS: 'documents',
  STAMPS: 'stamps',
  SIGNATURES: 'signatures',
  PROJECT_FILES: 'project-files',
  AVATARS: 'avatars',
  DEMO_TEMPLATES: 'demo-templates'
};

/* ============================================
   ORDER STATUS
   ============================================ */

export const ORDER_STATUS = {
  FORM_SUBMITTED: 'form_submitted',
  DEMO_VIEWED: 'demo_viewed',
  PAYMENT_PENDING: 'payment_pending',
  SCREENSHOT_UPLOADED: 'screenshot_uploaded',
  ADMIN_REVIEW: 'admin_review',
  APPROVED: 'approved',
  REJECTED: 'rejected',
  DELIVERED: 'delivered',
  CANCELLED: 'cancelled'
};

/* ============================================
   PAYMENT STATUS
   ============================================ */

export const PAYMENT_STATUS = {
  PENDING: 'pending',
  VERIFIED: 'verified',
  REJECTED: 'rejected',
  REFUNDED: 'refunded'
};

/* ============================================
   USER ROLES
   ============================================ */

export const USER_ROLES = {
  CUSTOMER: 'customer',
  ADMIN: 'admin',
  SUPER_ADMIN: 'super_admin'
};

/* ============================================
   CATEGORIES
   ============================================ */

export const CATEGORIES = [
  { id: 'school', name: 'School Management System', icon: '🏫' },
  { id: 'business', name: 'Business / Company Website', icon: '🏢' },
  { id: 'ecommerce', name: 'E-commerce Store', icon: '🛒' },
  { id: 'portfolio', name: 'Portfolio / Personal Website', icon: '👤' },
  { id: 'landing', name: 'Landing Page / Sales Page', icon: '📢' },
  { id: 'blog', name: 'Blog / News Website', icon: '📰' },
  { id: 'mobile-app', name: 'Mobile App', icon: '📱' },
  { id: 'saas', name: 'Custom / SaaS Dashboard', icon: '⚙️' },
  { id: 'other', name: 'Other', icon: '✨' }
];

/* ============================================
   PRICING PLANS
   ============================================ */

export const PRICING_PLANS = {
  MONTHLY: {
    id: 'monthly',
    name: 'Monthly',
    priceUSD: 20,
    priceINR: 1650,
    period: 'month'
  },
  YEARLY: {
    id: 'yearly',
    name: 'Yearly',
    priceUSD: 216,
    priceINR: 18000,
    period: 'year'
  },
  ONE_TIME: {
    id: 'one-time',
    name: 'One-time',
    priceUSD: 500,
    priceINR: 41500,
    period: 'once'
  },
  WITH_CODE: {
    id: 'with-code',
    name: 'With Code',
    priceUSD: 1550,
    priceINR: 128000,
    period: 'once'
  },
  MAINTENANCE: {
    id: 'maintenance',
    name: 'Maintenance',
    priceUSD: 10,
    priceINR: 825,
    period: 'month'
  }
};

/* ============================================
   UTILITY: Check Connection
   ============================================ */

export async function checkConnection() {
  try {
    const { data, error } = await supabase
      .from(TABLES.SETTINGS)
      .select('id')
      .limit(1);

    if (error) {
      console.error('❌ Supabase connection error:', error.message);
      return false;
    }

    console.log('✅ Supabase connected');
    return true;
  } catch (err) {
    console.error('❌ Supabase connection failed:', err);
    return false;
  }
}

/* ============================================
   UTILITY: Get Current User
   ============================================ */

export async function getCurrentUser() {
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error) {
    console.error('Error getting user:', error.message);
    return null;
  }
  return user;
}

/* ============================================
   UTILITY: Get Session
   ============================================ */

export async function getSession() {
  const { data: { session }, error } = await supabase.auth.getSession();
  if (error) {
    console.error('Error getting session:', error.message);
    return null;
  }
  return session;
}

/* ============================================
   UTILITY: Log Activity
   ============================================ */

export async function logActivity(userId, action, details = {}) {
  try {
    const { error } = await supabase
      .from(TABLES.ACTIVITY_LOGS)
      .insert({
        user_id: userId,
        action,
        details,
        created_at: new Date().toISOString()
      });

    if (error) {
      console.error('Error logging activity:', error.message);
    }
  } catch (err) {
    console.error('Activity log failed:', err);
  }
}

/* ============================================
   EXPORT DEFAULT
   ============================================ */

export default supabase;