/* ============================================
   Tarzen Web Devp. — Form Logic
   Order Form, Multi-Step, Validation, Submit
   ============================================ */

import { supabase, TABLES, ORDER_STATUS, CATEGORIES, logActivity } from './supabase.js';
import { getCurrentUser, requireAuth } from './auth.js';
import { showToast, showLoading, hideLoading, generateOrderId } from './app.js';

/* ============================================
   FORM STATE
   ============================================ */

let currentStep = 1;
const totalSteps = 3;

let formData = {
  // Step 1: Personal
  name: '',
  email: '',
  phone: '',
  city: '',

  // Step 2: Business
  business_name: '',
  address: '',
  state: '',
  pincode: '',
  gst: '',
  reference: '',

  // Step 3: Project
  category: '',
  message: ''
};

/* ============================================
   INIT FORM
   ============================================ */

export async function initForm() {
  const user = await requireAuth();
  if (!user) return;

  // Pre-fill email
  const emailInput = document.getElementById('email');
  if (emailInput && user.email) {
    emailInput.value = user.email;
    emailInput.readOnly = true;
    formData.email = user.email;
  }

  // Load draft if exists
  loadDraft();

  // Setup step navigation
  setupStepNavigation();

  // Setup category selection
  setupCategorySelection();

  // Setup input listeners
  setupInputListeners();

  // Setup draft auto-save
  setupDraftAutoSave();

  // Update UI
  updateStepUI();
}

/* ============================================
   STEP NAVIGATION
   ============================================ */

function setupStepNavigation() {
  const nextBtns = document.querySelectorAll('[data-next-step]');
  const prevBtns = document.querySelectorAll('[data-prev-step]');
  const submitBtn = document.getElementById('submitForm');

  nextBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      if (validateCurrentStep()) {
        nextStep();
      }
    });
  });

  prevBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      prevStep();
    });
  });

  if (submitBtn) {
    submitBtn.addEventListener('click', (e) => {
      e.preventDefault();
      handleSubmit(e);
    });
  }
}

function nextStep() {
  if (currentStep < totalSteps) {
    currentStep++;
    updateStepUI();
    scrollToFormTop();
  }
}

function prevStep() {
  if (currentStep > 1) {
    currentStep--;
    updateStepUI();
    scrollToFormTop();
  }
}

function updateStepUI() {
  // Update step contents
  document.querySelectorAll('.form-step-content').forEach((el, index) => {
    el.classList.toggle('active', index + 1 === currentStep);
  });

  // Update step indicators
  document.querySelectorAll('.form-step').forEach((el, index) => {
    const stepNum = index + 1;
    el.classList.remove('active', 'completed');
    if (stepNum === currentStep) el.classList.add('active');
    if (stepNum < currentStep) el.classList.add('completed');
  });

  // Update progress bar
  const progress = document.querySelector('.form-steps-progress');
  if (progress) {
    const percent = ((currentStep - 1) / (totalSteps - 1)) * 80;
    progress.style.width = `${percent}%`;
  }
}

function scrollToFormTop() {
  const formCard = document.querySelector('.form-card');
  if (formCard) {
    const top = formCard.getBoundingClientRect().top + window.scrollY - 100;
    window.scrollTo({ top, behavior: 'smooth' });
  }
}

/* ============================================
   CATEGORY SELECTION
   ============================================ */

function setupCategorySelection() {
  const options = document.querySelectorAll('.category-option');

  options.forEach(option => {
    option.addEventListener('click', () => {
      options.forEach(o => o.classList.remove('selected'));
      option.classList.add('selected');

      const input = option.querySelector('input');
      if (input) {
        input.checked = true;
        formData.category = input.value;
        saveDraft();
      }
    });
  });
}

/* ============================================
   INPUT LISTENERS
   ============================================ */

function setupInputListeners() {
  const inputs = document.querySelectorAll('[data-field]');

  inputs.forEach(input => {
    input.addEventListener('input', (e) => {
      const field = e.target.dataset.field;
      formData[field] = e.target.value;
      clearFieldError(e.target);
    });

    input.addEventListener('blur', (e) => {
      const field = e.target.dataset.field;
      validateField(field, e.target.value, e.target);
    });
  });
}

/* ============================================
   VALIDATION
   ============================================ */

function validateCurrentStep() {
  let isValid = true;

  if (currentStep === 1) {
    isValid = validateStep1();
  } else if (currentStep === 2) {
    isValid = validateStep2();
  } else if (currentStep === 3) {
    isValid = validateStep3();
  }

  return isValid;
}

function validateStep1() {
  let valid = true;

  const nameInput = document.getElementById('name');
  if (!formData.name || formData.name.trim().length < 2) {
    showFieldError(nameInput, 'Name is required (min 2 characters)');
    valid = false;
  }

  const emailInput = document.getElementById('email');
  if (!formData.email || !isValidEmail(formData.email)) {
    showFieldError(emailInput, 'Valid email is required');
    valid = false;
  }

  const phoneInput = document.getElementById('phone');
  if (formData.phone && !isValidPhone(formData.phone)) {
    showFieldError(phoneInput, 'Invalid phone number');
    valid = false;
  }

  const cityInput = document.getElementById('city');
  if (!formData.city || formData.city.trim().length < 2) {
    showFieldError(cityInput, 'City is required');
    valid = false;
  }

  if (!valid) {
    showToast('Please fix the errors above', 'danger');
  }

  return valid;
}

function validateStep2() {
  let valid = true;

  const businessInput = document.getElementById('business_name');
  if (!formData.business_name || formData.business_name.trim().length < 2) {
    showFieldError(businessInput, 'Business/School name is required');
    valid = false;
  }

  if (formData.pincode && !/^\d{6}$/.test(formData.pincode)) {
    const pincodeInput = document.getElementById('pincode');
    showFieldError(pincodeInput, 'Pincode must be 6 digits');
    valid = false;
  }

  if (formData.gst && !isValidGST(formData.gst)) {
    const gstInput = document.getElementById('gst');
    showFieldError(gstInput, 'Invalid GST format');
    valid = false;
  }

  if (!valid) {
    showToast('Please fix the errors above', 'danger');
  }

  return valid;
}

function validateStep3() {
  let valid = true;

  if (!formData.category) {
    showToast('Please select a category', 'danger');
    valid = false;
  }

  return valid;
}

function validateField(field, value, input) {
  if (!value) return true;

  switch (field) {
    case 'email':
      if (!isValidEmail(value)) {
        showFieldError(input, 'Invalid email');
        return false;
      }
      break;
    case 'phone':
      if (!isValidPhone(value)) {
        showFieldError(input, 'Invalid phone number');
        return false;
      }
      break;
    case 'pincode':
      if (!/^\d{6}$/.test(value)) {
        showFieldError(input, 'Pincode must be 6 digits');
        return false;
      }
      break;
    case 'gst':
      if (!isValidGST(value)) {
        showFieldError(input, 'Invalid GST format');
        return false;
      }
      break;
  }

  clearFieldError(input);
  return true;
}

/* ============================================
   ERROR DISPLAY
   ============================================ */

function showFieldError(input, message) {
  if (!input) return;

  input.classList.add('error');

  // Remove existing error
  const parent = input.closest('.form-field') || input.parentElement;
  const existing = parent.querySelector('.form-error');
  if (existing) existing.remove();

  const error = document.createElement('span');
  error.className = 'form-error';
  error.textContent = message;
  input.parentElement.appendChild(error);
}

function clearFieldError(input) {
  if (!input) return;

  input.classList.remove('error');
  const parent = input.closest('.form-field') || input.parentElement;
  const error = parent.querySelector('.form-error');
  if (error) error.remove();
}

/* ============================================
   VALIDATORS
   ============================================ */

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function isValidPhone(phone) {
  const cleaned = phone.replace(/\D/g, '');
  return cleaned.length >= 10 && cleaned.length <= 13;
}

function isValidGST(gst) {
  return /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(gst.toUpperCase());
}

/* ============================================
   DRAFT MANAGEMENT
   ============================================ */

function saveDraft() {
  try {
    localStorage.setItem('tarzen_form_draft', JSON.stringify(formData));
  } catch (err) {
    console.error('Draft save error:', err);
  }
}

function loadDraft() {
  try {
    const draft = localStorage.getItem('tarzen_form_draft');
    if (!draft) return;

    const parsed = JSON.parse(draft);
    formData = { ...formData, ...parsed };

    // Fill inputs
    Object.keys(formData).forEach(key => {
      const input = document.querySelector(`[data-field="${key}"]`);
      if (input && formData[key]) {
        input.value = formData[key];
      }
    });

    // Restore category selection
    if (formData.category) {
      const option = document.querySelector(`.category-option input[value="${formData.category}"]`);
      if (option) {
        option.checked = true;
        option.closest('.category-option').classList.add('selected');
      }
    }

    showToast('Draft loaded', 'info', 2000);
  } catch (err) {
    console.error('Draft load error:', err);
  }
}

function setupDraftAutoSave() {
  setInterval(() => {
    if (formData.name || formData.email || formData.business_name) {
      saveDraft();
    }
  }, 10000); // Every 10 seconds
}

function clearDraft() {
  localStorage.removeItem('tarzen_form_draft');
}

/* ============================================
   SUBMIT FORM
   ============================================ */

async function handleSubmit(e) {
  e.preventDefault();

  if (!validateCurrentStep()) return;

  const submitBtn = document.getElementById('submitForm');
  showLoading(submitBtn);

  try {
    const user = await getCurrentUser();
    if (!user) throw new Error('Not logged in');

    const orderId = generateOrderId();

    // 1. Create order
    const { data: order, error: orderError } = await supabase
      .from(TABLES.ORDERS)
      .insert({
        id: orderId,
        user_id: user.id,
        category: formData.category,
        status: ORDER_STATUS.FORM_SUBMITTED,
        created_at: new Date().toISOString()
      })
      .select()
      .single();

    if (orderError) throw orderError;

    // 2. Create form data
    const { error: formError } = await supabase
      .from(TABLES.FORM_DATA)
      .insert({
        order_id: order.id,
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        business_name: formData.business_name,
        address: formData.address,
        state: formData.state,
        pincode: formData.pincode,
        gst: formData.gst,
        city: formData.city,
        reference: formData.reference,
        message: formData.message,
        created_at: new Date().toISOString()
      });

    if (formError) throw formError;

    // 3. Log activity
    await logActivity(user.id, 'order_created', {
      order_id: order.id,
      category: formData.category
    });

    // 4. Clear draft
    clearDraft();

    // 5. Redirect to confirmation
    sessionStorage.setItem('order_id', order.id);
    window.location.href = `demo.html?order=${order.id}`;

  } catch (error) {
    console.error('Submit error:', error.message);
    showToast('Failed to submit form: ' + (error.message || 'Unknown error'), 'danger');
  } finally {
    hideLoading(submitBtn);
  }
}

/* ============================================
   UTILITY: Get Form Data
   ============================================ */

export function getFormData() {
  return { ...formData };
}

export function setFormData(data) {
  formData = { ...formData, ...data };
}

export function resetForm() {
  formData = {
    name: '',
    email: '',
    phone: '',
    city: '',
    business_name: '',
    address: '',
    state: '',
    pincode: '',
    gst: '',
    reference: '',
    category: '',
    message: ''
  };
  currentStep = 1;
  clearDraft();
}

/* ============================================
   AUTO-INIT
   ============================================ */

if (document.querySelector('.form-steps')) {
  document.addEventListener('DOMContentLoaded', initForm);
}

/* ============================================
   EXPORT DEFAULT
   ============================================ */

export default {
  initForm,
  getFormData,
  setFormData,
  resetForm
};