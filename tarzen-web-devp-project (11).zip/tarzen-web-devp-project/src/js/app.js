/* ============================================
   Tarzen Web Devp. — Main App JS
   Common Functions, UI, Utilities
   ============================================ */

import { checkConnection } from './supabase.js';

/* ============================================
   APP INITIALIZATION
   ============================================ */

document.addEventListener('DOMContentLoaded', async () => {
  console.log('🚀 Tarzen Web Devp. loaded');

  // Check Supabase connection (only on first load)
  if (!sessionStorage.getItem('connection_checked')) {
    await checkConnection();
    sessionStorage.setItem('connection_checked', 'true');
  }

  initNavbar();
  initMobileMenu();
  initSmoothScroll();
  initFAQAccordion();
  initDarkMode();
  initScrollReveal();
  initTilt();
  initBackToTop();
  initYear();
});

/* ============================================
   NAVBAR — Scroll Effect
   ============================================ */

function initNavbar() {
  const navbar = document.querySelector('.navbar');
  if (!navbar) return;

  let lastScroll = 0;

  window.addEventListener('scroll', () => {
    const currentScroll = window.scrollY;

    if (currentScroll > 50) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }

    // Hide on scroll down, show on scroll up (optional)
    if (currentScroll > lastScroll && currentScroll > 300) {
      navbar.style.transform = 'translateY(-100%)';
    } else {
      navbar.style.transform = 'translateY(0)';
    }

    lastScroll = currentScroll;
  }, { passive: true });
}

/* ============================================
   MOBILE MENU TOGGLE
   ============================================ */

function initMobileMenu() {
  const navToggle = document.getElementById('navToggle');
  const navMenu = document.getElementById('navMenu');

  if (!navToggle || !navMenu) return;

  navToggle.addEventListener('click', () => {
    navToggle.classList.toggle('active');
    navMenu.classList.toggle('active');
    document.body.style.overflow = navMenu.classList.contains('active') ? 'hidden' : '';
  });

  // Close menu on link click
  navMenu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      navToggle.classList.remove('active');
      navMenu.classList.remove('active');
      document.body.style.overflow = '';
    });
  });

  // Close on outside click
  document.addEventListener('click', (e) => {
    if (navMenu.classList.contains('active') &&
        !navMenu.contains(e.target) &&
        !navToggle.contains(e.target)) {
      navToggle.classList.remove('active');
      navMenu.classList.remove('active');
      document.body.style.overflow = '';
    }
  });
}

/* ============================================
   SMOOTH SCROLL
   ============================================ */

function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', (e) => {
      const href = link.getAttribute('href');
      if (href === '#' || href === '') return;

      const target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        const offset = 80;
        const targetPosition = target.getBoundingClientRect().top + window.scrollY - offset;

        window.scrollTo({
          top: targetPosition,
          behavior: 'smooth'
        });

        // Close mobile menu
        const navMenu = document.getElementById('navMenu');
        const navToggle = document.getElementById('navToggle');
        if (navMenu?.classList.contains('active')) {
          navMenu.classList.remove('active');
          navToggle?.classList.remove('active');
          document.body.style.overflow = '';
        }
      }
    });
  });
}

/* ============================================
   FAQ ACCORDION
   ============================================ */

function initFAQAccordion() {
  const faqItems = document.querySelectorAll('.faq-item');
  if (!faqItems.length) return;

  faqItems.forEach(item => {
    item.addEventListener('toggle', () => {
      if (item.open) {
        faqItems.forEach(other => {
          if (other !== item && other.open) {
            other.open = false;
          }
        });
      }
    });
  });
}

/* ============================================
   DARK MODE TOGGLE
   ============================================ */

function initDarkMode() {
  const themeToggle = document.getElementById('themeToggle');

  // Apply saved theme
  const savedTheme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);

  if (!themeToggle) return;

  // Update icon
  updateThemeIcon(savedTheme);

  themeToggle.addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : 'dark';

    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);
    updateThemeIcon(next);
  });
}

function updateThemeIcon(theme) {
  const themeToggle = document.getElementById('themeToggle');
  if (themeToggle) {
    themeToggle.textContent = theme === 'dark' ? '☀️' : '🌙';
  }
}

/* ============================================
   SCROLL REVEAL
   ============================================ */

function initScrollReveal() {
  const reveals = document.querySelectorAll('.scroll-reveal');
  if (!reveals.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('revealed');
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  });

  reveals.forEach(el => observer.observe(el));
}

/* ============================================
   3D POINTER TILT (fine pointers only)
   Gentle preserve-3d tilt on cards, driven by
   requestAnimationFrame; transform/opacity
   only, disabled for reduced motion.
   ============================================ */

function initTilt() {
  const finePointer = window.matchMedia('(pointer: fine)');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  if (!finePointer.matches || reducedMotion.matches) return;
  if (window.innerWidth < 1024) return;

  const selector = [
    '.feature-card',
    '.category-card',
    '.pricing-card',
    '.testimonial-card',
    '.document-card',
    '.category-option',
    '.stat-card',
    '.admin-stat-card',
    '.hero-mockup'
  ].join(', ');

  const MAX_TILT = 7; // degrees — matches --tilt-max

  document.querySelectorAll(selector).forEach((el) => {
    el.classList.add('tilt');
    let raf = null;

    el.addEventListener('pointermove', (e) => {
      const rect = el.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      const px = (e.clientX - rect.left) / rect.width - 0.5;
      const py = (e.clientY - rect.top) / rect.height - 0.5;
      if (raf) cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const base = el.classList.contains('popular') ? ' scale(1.03)' : '';
        el.style.transition = 'transform 0.12s ease-out';
        el.style.transform =
          'perspective(900px)' +
          ' rotateX(' + (-py * MAX_TILT).toFixed(2) + 'deg)' +
          ' rotateY(' + (px * MAX_TILT).toFixed(2) + 'deg)' +
          ' translateY(-4px)' + base;
      });
    });

    el.addEventListener('pointerleave', () => {
      if (raf) cancelAnimationFrame(raf);
      el.style.transition = '';
      el.style.transform = '';
    });
  });
}

/* ============================================
   BACK TO TOP BUTTON
   ============================================ */

function initBackToTop() {
  const btn = document.getElementById('backToTop');
  if (!btn) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 400) {
      btn.classList.add('visible');
    } else {
      btn.classList.remove('visible');
    }
  }, { passive: true });

  btn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

/* ============================================
   CURRENT YEAR IN FOOTER
   ============================================ */

function initYear() {
  const yearEl = document.getElementById('currentYear');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
}

/* ============================================
   UTILITY: Format Currency
   ============================================ */

export function formatCurrency(amount, currency = 'INR') {
  const symbols = { INR: '₹', USD: '$', EUR: '€', GBP: '£' };
  const symbol = symbols[currency] || '';

  const formatted = Number(amount).toLocaleString('en-IN', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2
  });

  return `${symbol}${formatted}`;
}

/* ============================================
   UTILITY: Format Date
   ============================================ */

export function formatDate(date, format = 'short') {
  const d = new Date(date);

  if (format === 'short') {
    return d.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  }

  if (format === 'long') {
    return d.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      weekday: 'long'
    });
  }

  if (format === 'time') {
    return d.toLocaleTimeString('en-IN', {
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  if (format === 'datetime') {
    return d.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  return d.toLocaleDateString('en-IN');
}

/* ============================================
   UTILITY: Time Ago
   ============================================ */

export function timeAgo(date) {
  const seconds = Math.floor((new Date() - new Date(date)) / 1000);

  const intervals = {
    year: 31536000,
    month: 2592000,
    week: 604800,
    day: 86400,
    hour: 3600,
    minute: 60
  };

  for (const [unit, secs] of Object.entries(intervals)) {
    const count = Math.floor(seconds / secs);
    if (count >= 1) {
      return `${count} ${unit}${count > 1 ? 's' : ''} ago`;
    }
  }

  return 'Just now';
}

/* ============================================
   UTILITY: Format File Size
   ============================================ */

export function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';

  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/* ============================================
   UTILITY: Format Timer (seconds → MM:SS)
   ============================================ */

export function formatTimer(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

/* ============================================
   UTILITY: Show Toast
   ============================================ */

export function showToast(message, type = 'info', duration = 3000) {
  // Remove existing toast container
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const icons = {
    success: '✅',
    danger: '❌',
    warning: '⚠️',
    info: 'ℹ️'
  };

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span class="toast-icon">${icons[type] || icons.info}</span>
    <div class="toast-content">${message}</div>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.animation = 'fadeOut 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

/* ============================================
   UTILITY: Show Loading
   ============================================ */

export function showLoading(button) {
  if (!button) return;
  button.classList.add('loading');
  button.disabled = true;
}

export function hideLoading(button) {
  if (!button) return;
  button.classList.remove('loading');
  button.disabled = false;
}

/* ============================================
   UTILITY: Debounce
   ============================================ */

export function debounce(func, wait = 300) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

/* ============================================
   UTILITY: Throttle
   ============================================ */

export function throttle(func, limit = 300) {
  let inThrottle;
  return function (...args) {
    if (!inThrottle) {
      func.apply(this, args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
}

/* ============================================
   UTILITY: Copy to Clipboard
   ============================================ */

export async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    showToast('Copied to clipboard!', 'success');
    return true;
  } catch (err) {
    console.error('Copy failed:', err);
    showToast('Failed to copy', 'danger');
    return false;
  }
}

/* ============================================
   UTILITY: Generate Order ID
   ============================================ */

export function generateOrderId() {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `TZN-${timestamp}-${random}`;
}

/* ============================================
   UTILITY: Truncate Text
   ============================================ */

export function truncate(text, length = 50) {
  if (!text) return '';
  return text.length > length ? text.substring(0, length) + '...' : text;
}

/* ============================================
   UTILITY: Get Initials
   ============================================ */

export function getInitials(name) {
  if (!name) return '?';
  return name
    .split(' ')
    .map(word => word[0])
    .join('')
    .toUpperCase()
    .substring(0, 2);
}

/* ============================================
   UTILITY: Validate URL
   ============================================ */

export function isValidUrl(string) {
  try {
    new URL(string);
    return true;
  } catch {
    return false;
  }
}

/* ============================================
   UTILITY: Scroll to Element
   ============================================ */

export function scrollToElement(selector, offset = 80) {
  const target = document.querySelector(selector);
  if (!target) return;

  const targetPosition = target.getBoundingClientRect().top + window.scrollY - offset;
  window.scrollTo({ top: targetPosition, behavior: 'smooth' });
}

/* ============================================
   UTILITY: Get Query Param
   ============================================ */

export function getQueryParam(param) {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get(param);
}

/* ============================================
   UTILITY: Set Query Param
   ============================================ */

export function setQueryParam(param, value) {
  const url = new URL(window.location);
  url.searchParams.set(param, value);
  window.history.replaceState({}, '', url);
}

/* ============================================
   UTILITY: Confirm Dialog
   ============================================ */

export function confirmDialog(message, title = 'Confirm') {
  return new Promise((resolve) => {
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop';
    backdrop.innerHTML = `
      <div class="modal" style="max-width: 400px;">
        <div class="modal-header">
          <h3>${title}</h3>
        </div>
        <div class="modal-body">
          <p>${message}</p>
        </div>
        <div class="modal-footer">
          <button class="btn btn-outline" data-action="cancel">Cancel</button>
          <button class="btn btn-danger" data-action="confirm">Confirm</button>
        </div>
      </div>
    `;

    document.body.appendChild(backdrop);

    backdrop.addEventListener('click', (e) => {
      const action = e.target.dataset.action;
      if (action === 'confirm') {
        backdrop.remove();
        resolve(true);
      } else if (action === 'cancel' || e.target === backdrop) {
        backdrop.remove();
        resolve(false);
      }
    });
  });
}

/* ============================================
   UTILITY: Image Preview
   ============================================ */

export function previewImage(file) {
  return new Promise((resolve, reject) => {
    if (!file) return reject('No file');

    if (!file.type.startsWith('image/')) {
      return reject('Not an image');
    }

    const reader = new FileReader();
    reader.onload = (e) => resolve(e.target.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

/* ============================================
   UTILITY: Validate File
   ============================================ */

export function validateFile(file, options = {}) {
  const {
    maxSize = 5 * 1024 * 1024, // 5MB
    allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf']
  } = options;

  if (!file) {
    return { valid: false, error: 'No file selected' };
  }

  if (file.size > maxSize) {
    return { valid: false, error: `File too large. Max ${formatFileSize(maxSize)}` };
  }

  if (!allowedTypes.includes(file.type)) {
    return { valid: false, error: 'Invalid file type' };
  }

  return { valid: true, error: null };
}

/* ============================================
   UTILITY: Download File
   ============================================ */

export function downloadFile(url, filename) {
  const link = document.createElement('a');
  link.href = url;
  link.download = filename || 'download';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/* ============================================
   UTILITY: Print Element
   ============================================ */

export function printElement(elementId) {
  const element = document.getElementById(elementId);
  if (!element) return;

  const printWindow = window.open('', '_blank');
  printWindow.document.write(`
    <html>
      <head>
        <title>Print</title>
        <link rel="stylesheet" href="../css/variables.css">
        <link rel="stylesheet" href="../css/style.css">
      </head>
      <body>${element.innerHTML}</body>
    </html>
  `);
  printWindow.document.close();
  printWindow.focus();
  setTimeout(() => {
    printWindow.print();
    printWindow.close();
  }, 500);
}

/* ============================================
   EXPORT DEFAULT
   ============================================ */

export default {
  formatCurrency,
  formatDate,
  timeAgo,
  formatFileSize,
  formatTimer,
  showToast,
  showLoading,
  hideLoading,
  debounce,
  throttle,
  copyToClipboard,
  generateOrderId,
  truncate,
  getInitials,
  isValidUrl,
  scrollToElement,
  getQueryParam,
  setQueryParam,
  confirmDialog,
  previewImage,
  validateFile,
  downloadFile,
  printElement
};