/* ============================================
   Tarzen Web Devp. — Demo Viewer
   5-Minute Timer, Demo Load, Skip, Changes
   ============================================ */

import { supabase, TABLES, ORDER_STATUS, CATEGORIES, logActivity } from './supabase.js';
import { getCurrentUser, requireAuth } from './auth.js';
import { showToast, formatTimer, getQueryParam } from './app.js';

/* ============================================
   DEMO STATE
   ============================================ */

const DEMO_DURATION = 5 * 60; // 5 minutes in seconds
const DEMO_TEMPLATES_PATH = '../assets/demo-templates/';

let timerInterval = null;
let timeRemaining = DEMO_DURATION;
let isPaused = false;
let orderId = null;
let category = null;

/* ============================================
   INIT DEMO
   ============================================ */

export async function initDemo() {
  const user = await requireAuth();
  if (!user) return;

  orderId = getQueryParam('order');
  if (!orderId) {
    showToast('Order not found', 'danger');
    setTimeout(() => window.location.href = 'dashboard.html', 1500);
    return;
  }

  // Load order details
  const { data: order, error } = await supabase
    .from(TABLES.ORDERS)
    .select('*')
    .eq('id', orderId)
    .eq('user_id', user.id)
    .single();

  if (error || !order) {
    showToast('Order not found', 'danger');
    setTimeout(() => window.location.href = 'dashboard.html', 1500);
    return;
  }

  category = order.category;

  // Load demo
  loadDemo(category);

  // Update UI
  updateDemoHeader(category);

  // Start timer
  startTimer();

  // Setup controls
  setupControls();
}

/* ============================================
   LOAD DEMO
   ============================================ */

function loadDemo(categoryId) {
  const iframe = document.getElementById('demoFrame');
  if (!iframe) return;

  const demoUrl = `${DEMO_TEMPLATES_PATH}${categoryId}/index.html`;

  iframe.src = demoUrl;
  iframe.onload = () => {
    console.log(`✅ Demo loaded: ${categoryId}`);
  };
  iframe.onerror = () => {
    console.error(`❌ Demo failed: ${categoryId}`);
    iframe.src = `${DEMO_TEMPLATES_PATH}other/index.html`;
  };
}

function updateDemoHeader(categoryId) {
  const categoryData = CATEGORIES.find(c => c.id === categoryId);
  const titleEl = document.getElementById('demoTitle');
  const iconEl = document.getElementById('demoIcon');

  if (titleEl && categoryData) {
    titleEl.textContent = categoryData.name;
  }
  if (iconEl && categoryData) {
    iconEl.textContent = categoryData.icon;
  }
}

/* ============================================
   TIMER
   ============================================ */

function startTimer() {
  const timerEl = document.getElementById('demoTimer');
  const timerTextEl = document.getElementById('timerText');

  updateTimerDisplay();

  timerInterval = setInterval(() => {
    if (isPaused) return;

    timeRemaining--;

    if (timeRemaining <= 0) {
      clearInterval(timerInterval);
      onTimerComplete();
      return;
    }

    updateTimerDisplay();

    // Warning colors
    if (timerEl) {
      timerEl.classList.remove('warning', 'danger');
      if (timeRemaining <= 30) {
        timerEl.classList.add('danger');
      } else if (timeRemaining <= 60) {
        timerEl.classList.add('warning');
      }
    }
  }, 1000);
}

function updateTimerDisplay() {
  const timerTextEl = document.getElementById('timerText');
  if (timerTextEl) {
    timerTextEl.textContent = formatTimer(timeRemaining);
  }
}

function onTimerComplete() {
  showToast('Demo time complete!', 'info');
  goToPayment();
}

function pauseTimer() {
  isPaused = true;
}

function resumeTimer() {
  isPaused = false;
}

/* ============================================
   CONTROLS
   ============================================ */

function setupControls() {
  const skipBtn = document.getElementById('skipDemo');
  const getDemoBtn = document.getElementById('getThisDemo');
  const changesBtn = document.getElementById('requestChanges');
  const mobileBtn = document.getElementById('viewMobile');
  const desktopBtn = document.getElementById('viewDesktop');
  const pauseBtn = document.getElementById('pauseTimer');

  if (skipBtn) {
    skipBtn.addEventListener('click', () => {
      if (confirm('Skip demo and go to payment?')) {
        goToPayment();
      }
    });
  }

  if (getDemoBtn) {
    getDemoBtn.addEventListener('click', goToPayment);
  }

  if (changesBtn) {
    changesBtn.addEventListener('click', openChangesModal);
  }

  if (mobileBtn) {
    mobileBtn.addEventListener('click', () => toggleView('mobile'));
  }

  if (desktopBtn) {
    desktopBtn.addEventListener('click', () => toggleView('desktop'));
  }

  if (pauseBtn) {
    pauseBtn.addEventListener('click', togglePause);
  }
}

function toggleView(mode) {
  const wrapper = document.getElementById('demoWrapper');
  const mobileBtn = document.getElementById('viewMobile');
  const desktopBtn = document.getElementById('viewDesktop');

  if (!wrapper) return;

  wrapper.classList.remove('view-mobile', 'view-desktop');
  wrapper.classList.add(`view-${mode}`);

  mobileBtn?.classList.toggle('active', mode === 'mobile');
  desktopBtn?.classList.toggle('active', mode === 'desktop');
}

function togglePause() {
  const btn = document.getElementById('pauseTimer');
  if (isPaused) {
    resumeTimer();
    if (btn) btn.textContent = '⏸️ Pause';
  } else {
    pauseTimer();
    if (btn) btn.textContent = '▶️ Resume';
  }
}

/* ============================================
   CHANGES REQUEST
   ============================================ */

function openChangesModal() {
  const modal = document.getElementById('changesModal');
  if (modal) {
    modal.classList.add('active');
    pauseTimer();
  }
}

function closeChangesModal() {
  const modal = document.getElementById('changesModal');
  if (modal) {
    modal.classList.remove('active');
    resumeTimer();
  }
}

async function submitChanges() {
  const textarea = document.getElementById('changesText');
  const notes = textarea?.value.trim();

  if (!notes) {
    showToast('Please describe the changes', 'warning');
    return;
  }

  try {
    const user = await getCurrentUser();
    if (!user) throw new Error('Not logged in');

    // Save changes to order
    await supabase
      .from(TABLES.FORM_DATA)
      .update({ message: notes })
      .eq('order_id', orderId);

    await logActivity(user.id, 'demo_changes_requested', {
      order_id: orderId,
      notes
    });

    showToast('Changes requested! Admin will review.', 'success');
    closeChangesModal();
    textarea.value = '';
  } catch (error) {
    console.error('Changes error:', error.message);
    showToast('Failed to submit changes: ' + (error.message || 'Unknown error'), 'danger');
  }
}

/* ============================================
   GO TO PAYMENT
   ============================================ */

async function goToPayment() {
  if (timerInterval) clearInterval(timerInterval);

  try {
    const user = await getCurrentUser();
    if (!user) throw new Error('Not logged in');

    // Update order status
    await supabase
      .from(TABLES.ORDERS)
      .update({ status: ORDER_STATUS.DEMO_VIEWED })
      .eq('id', orderId);

    await logActivity(user.id, 'demo_viewed', { order_id: orderId });

    // Redirect to payment
    window.location.href = `payment.html?order=${orderId}`;
  } catch (error) {
    console.error('Redirect error:', error.message);
    window.location.href = `payment.html?order=${orderId}`;
  }
}

/* ============================================
   CLEANUP
   ============================================ */

export function stopDemo() {
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
}

window.addEventListener('beforeunload', stopDemo);

/* ============================================
   AUTO-INIT
   ============================================ */

if (document.getElementById('demoFrame')) {
  document.addEventListener('DOMContentLoaded', initDemo);
}

/* ============================================
   EXPORT DEFAULT
   ============================================ */

export default {
  initDemo,
  stopDemo
};