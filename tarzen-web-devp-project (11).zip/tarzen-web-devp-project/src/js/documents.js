/* ============================================
   Tarzen Web Devp. — Documents
   Bill, Agreement, Receipt Generation & Download
   ============================================ */

import { supabase, TABLES, ORDER_STATUS, logActivity } from './supabase.js';
import { getCurrentUser, requireAuth } from './auth.js';
import { showToast, formatCurrency, formatDate, getQueryParam } from './app.js';

/* ============================================
   DOCUMENTS STATE
   ============================================ */

let orderId = null;
let orderData = null;
let formData = null;
let companyData = null;
let documentsList = [];

/* ============================================
   INIT DOCUMENTS
   ============================================ */

export async function initDocuments() {
  const user = await requireAuth();
  if (!user) return;

  orderId = getQueryParam('order');
  if (!orderId) {
    showToast('Order not found', 'danger');
    setTimeout(() => window.location.href = 'dashboard.html', 1500);
    return;
  }

  await loadOrder(user.id);
  if (!orderData) return;

  await loadFormData();
  await loadCompanyData();
  await loadDocuments();

  updateDocumentsUI();
  setupControls();
}

/* ============================================
   LOAD ORDER
   ============================================ */

async function loadOrder(userId) {
  const { data: order, error } = await supabase
    .from(TABLES.ORDERS)
    .select('*')
    .eq('id', orderId)
    .eq('user_id', userId)
    .single();

  if (error || !order) {
    showToast('Order not found', 'danger');
    setTimeout(() => window.location.href = 'dashboard.html', 1500);
    return;
  }

  // Check approval status
  if (order.status !== ORDER_STATUS.APPROVED && order.status !== ORDER_STATUS.DELIVERED) {
    showToast('Documents will be available after approval', 'warning');
    setTimeout(() => window.location.href = `tracking.html?order=${orderId}`, 2000);
    return;
  }

  orderData = order;
}

/* ============================================
   LOAD FORM DATA
   ============================================ */

async function loadFormData() {
  const { data: form } = await supabase
    .from(TABLES.FORM_DATA)
    .select('*')
    .eq('order_id', orderId)
    .single();

  formData = form || {};
}

/* ============================================
   LOAD COMPANY DATA
   ============================================ */

async function loadCompanyData() {
  try {
    const { data, error } = await supabase
      .from(TABLES.SETTINGS)
      .select('value')
      .eq('key', 'company')
      .single();

    if (!error && data && data.value) {
      companyData = data.value;
    } else {
      companyData = getDefaultCompanyData();
    }
  } catch (err) {
    console.error('Company data error:', err);
    companyData = getDefaultCompanyData();
  }
}

function getDefaultCompanyData() {
  return {
    name: 'Tarzen Web Devp.',
    address: 'Your Address, City, State, India',
    gst: 'GSTIN123456789',
    phone: '',
    email: 'tarzenwebtech@outlook.com',
    logo: '',
    stamp: '',
    signature: ''
  };
}

/* ============================================
   LOAD DOCUMENTS
   ============================================ */

async function loadDocuments() {
  const { data: docs, error } = await supabase
    .from(TABLES.DOCUMENTS)
    .select('*')
    .eq('order_id', orderId);

  if (!error && docs) {
    documentsList = docs;
  }
}

/* ============================================
   UPDATE DOCUMENTS UI
   ============================================ */

function updateDocumentsUI() {
  const orderIdEl = document.getElementById('docOrderId');
  const customerEl = document.getElementById('docCustomer');
  const businessEl = document.getElementById('docBusiness');
  const dateEl = document.getElementById('docDate');

  if (orderIdEl) orderIdEl.textContent = orderId;
  if (customerEl && formData) customerEl.textContent = formData.name || '-';
  if (businessEl && formData) businessEl.textContent = formData.business_name || '-';
  if (dateEl) dateEl.textContent = formatDate(new Date());

  document.querySelectorAll('[data-doc-type]').forEach(card => {
    const type = card.dataset.docType;
    const doc = documentsList.find(d => d.type === type);
    const statusEl = card.querySelector('.doc-status');

    if (doc) {
      card.classList.add('available');
      if (statusEl) {
        statusEl.classList.add('available');
        statusEl.textContent = '✅ Available';
      }
    } else {
      card.classList.remove('available');
      if (statusEl) {
        statusEl.classList.remove('available');
        statusEl.textContent = '⏳ Ready to Download';
      }
    }
  });
}

/* ============================================
   SETUP CONTROLS
   ============================================ */

function setupControls() {
  document.querySelectorAll('[data-download]').forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.dataset.download;
      const size = btn.dataset.size || 'a4';
      downloadDocument(type, size);
    });
  });

  document.querySelectorAll('[data-preview]').forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.dataset.preview;
      previewDocument(type);
    });
  });

  document.querySelectorAll('[data-print]').forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.dataset.print;
      printDocument(type);
    });
  });

  const downloadAllBtn = document.getElementById('downloadAll');
  if (downloadAllBtn) {
    downloadAllBtn.addEventListener('click', downloadAll);
  }

  const closePreviewBtn = document.getElementById('closePreview');
  if (closePreviewBtn) {
    closePreviewBtn.addEventListener('click', closePreview);
  }
}

/* ============================================
   GENERATE BILL HTML
   ============================================ */

function generateBillHTML(size = 'a4') {
  const isA5 = size === 'a5';
  const pageWidth = isA5 ? '148mm' : '210mm';
  const pageHeight = isA5 ? '210mm' : '297mm';
  const padding = isA5 ? '10mm' : '15mm';
  const fs = isA5 ? '11px' : '13px';

  const company = companyData || getDefaultCompanyData();
  const form = formData || {};
  const order = orderData || {};

  const total = (order.final_amount || 0) * 1.18;
  const gst = (order.final_amount || 0) * 0.18;

  return `
    <div class="document-page" style="width: ${pageWidth}; min-height: ${pageHeight}; padding: ${padding}; background: white; font-family: Arial, sans-serif; color: #000;">
      <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #1E3A8A; padding-bottom: 16px; margin-bottom: 24px;">
        <div style="display: flex; gap: 16px; align-items: flex-start;">
          ${company.logo ? `<img src="${company.logo}" style="width: 64px; height: 64px; object-fit: contain;" />` : ''}
          <div>
            <h1 style="font-size: ${isA5 ? '18px' : '24px'}; font-weight: bold; color: #1E3A8A; margin: 0 0 4px;">${company.name}</h1>
            <p style="font-size: ${isA5 ? '10px' : '12px'}; color: #666; margin: 0;">${company.address}</p>
            <p style="font-size: ${isA5 ? '10px' : '12px'}; color: #666; margin: 2px 0;">GST: ${company.gst}</p>
            <p style="font-size: ${isA5 ? '10px' : '12px'}; color: #666; margin: 2px 0;">📞 ${company.phone} | ✉️ ${company.email}</p>
          </div>
        </div>
        <div style="text-align: right;">
          <h2 style="font-size: ${isA5 ? '20px' : '28px'}; color: #1E3A8A; margin: 0;">INVOICE</h2>
          <p style="font-size: ${fs}; margin: 4px 0;"><strong>#${orderId}</strong></p>
          <p style="font-size: ${fs}; color: #666; margin: 2px 0;">Date: ${formatDate(new Date())}</p>
        </div>
      </div>

      <div style="display: flex; justify-content: space-between; margin-bottom: 24px; gap: 24px;">
        <div style="flex: 1;">
          <h3 style="font-size: ${isA5 ? '12px' : '14px'}; color: #1E3A8A; border-bottom: 1px solid #ddd; padding-bottom: 4px; margin-bottom: 8px;">BILL TO</h3>
          <p style="font-size: ${fs}; margin: 4px 0;"><strong>${form.name || '-'}</strong></p>
          <p style="font-size: ${fs}; margin: 2px 0;">${form.business_name || '-'}</p>
          <p style="font-size: ${fs}; color: #666; margin: 2px 0;">${form.address || '-'}</p>
          <p style="font-size: ${fs}; color: #666; margin: 2px 0;">${form.city || ''} ${form.state || ''} ${form.pincode || ''}</p>
          <p style="font-size: ${fs}; color: #666; margin: 2px 0;">📞 ${form.phone || '-'}</p>
          <p style="font-size: ${fs}; color: #666; margin: 2px 0;">✉️ ${form.email || '-'}</p>
          ${form.gst ? `<p style="font-size: ${fs}; color: #666; margin: 2px 0;">GST: ${form.gst}</p>` : ''}
        </div>
        <div style="flex: 1;">
          <h3 style="font-size: ${isA5 ? '12px' : '14px'}; color: #1E3A8A; border-bottom: 1px solid #ddd; padding-bottom: 4px; margin-bottom: 8px;">PROJECT DETAILS</h3>
          <p style="font-size: ${fs}; margin: 4px 0;"><strong>Category:</strong> ${order.category || '-'}</p>
          <p style="font-size: ${fs}; margin: 2px 0;"><strong>Plan:</strong> ${order.plan || 'One-time'}</p>
          <p style="font-size: ${fs}; margin: 2px 0;"><strong>Status:</strong> Approved ✅</p>
        </div>
      </div>

      <table style="width: 100%; border-collapse: collapse; margin-bottom: 24px;">
        <thead>
          <tr style="background: #1E3A8A; color: white;">
            <th style="padding: ${isA5 ? '6px' : '10px'}; text-align: left; font-size: ${fs};">#</th>
            <th style="padding: ${isA5 ? '6px' : '10px'}; text-align: left; font-size: ${fs};">Description</th>
            <th style="padding: ${isA5 ? '6px' : '10px'}; text-align: right; font-size: ${fs};">Amount</th>
          </tr>
        </thead>
        <tbody>
          <tr style="border-bottom: 1px solid #eee;">
            <td style="padding: ${isA5 ? '8px' : '12px'}; font-size: ${fs};">1</td>
            <td style="padding: ${isA5 ? '8px' : '12px'}; font-size: ${fs};">
              ${order.category || 'Website'} Development<br>
              <span style="font-size: ${isA5 ? '9px' : '11px'}; color: #666;">Complete website with responsive design</span>
            </td>
            <td style="padding: ${isA5 ? '8px' : '12px'}; text-align: right; font-size: ${fs};">${formatCurrency(order.amount || 0, 'INR')}</td>
          </tr>
        </tbody>
      </table>

      <div style="margin-left: auto; width: ${isA5 ? '60%' : '50%'};">
        <div style="display: flex; justify-content: space-between; padding: 4px 0; font-size: ${fs};">
          <span>Subtotal:</span>
          <span>${formatCurrency(order.amount || 0, 'INR')}</span>
        </div>
        ${order.discount > 0 ? `
        <div style="display: flex; justify-content: space-between; padding: 4px 0; font-size: ${fs}; color: #10B981;">
          <span>Discount:</span>
          <span>- ${formatCurrency(order.discount, 'INR')}</span>
        </div>` : ''}
        <div style="display: flex; justify-content: space-between; padding: 4px 0; font-size: ${fs};">
          <span>GST (18%):</span>
          <span>${formatCurrency(gst, 'INR')}</span>
        </div>
        <div style="display: flex; justify-content: space-between; padding: 8px 0; margin-top: 8px; border-top: 2px solid #1E3A8A; font-size: ${isA5 ? '14px' : '16px'}; font-weight: bold; color: #1E3A8A;">
          <span>TOTAL:</span>
          <span>${formatCurrency(total, 'INR')}</span>
        </div>
      </div>

      <div style="margin-top: 32px; display: flex; justify-content: space-between; align-items: flex-end;">
        <div style="font-size: ${isA5 ? '9px' : '11px'}; color: #666;">
          <p>Thank you for your business!</p>
          <p>This is a computer-generated invoice.</p>
        </div>
        <div style="text-align: center;">
          ${company.signature ? `<img src="${company.signature}" style="height: 40px; margin-bottom: 4px;" />` : ''}
          <p style="font-size: ${isA5 ? '10px' : '12px'}; border-top: 1px solid #000; padding-top: 4px; margin: 0;">Authorized Signature</p>
          ${company.stamp ? `<img src="${company.stamp}" style="height: 60px; margin-top: 8px; opacity: 0.8;" />` : ''}
        </div>
      </div>
    </div>
  `;
}

/* ============================================
   GENERATE AGREEMENT HTML
   ============================================ */

function generateAgreementHTML(size = 'a4') {
  const isA5 = size === 'a5';
  const pageWidth = isA5 ? '148mm' : '210mm';
  const pageHeight = isA5 ? '210mm' : '297mm';
  const padding = isA5 ? '10mm' : '15mm';
  const fs = isA5 ? '10px' : '12px';

  const company = companyData || getDefaultCompanyData();
  const form = formData || {};
  const order = orderData || {};

  const total = (order.final_amount || 0) * 1.18;

  return `
    <div class="document-page" style="width: ${pageWidth}; min-height: ${pageHeight}; padding: ${padding}; background: white; font-family: Arial, sans-serif; color: #000;">
      <div style="text-align: center; border-bottom: 2px solid #1E3A8A; padding-bottom: 16px; margin-bottom: 24px;">
        <h1 style="font-size: ${isA5 ? '18px' : '24px'}; color: #1E3A8A; margin: 0 0 4px;">${company.name}</h1>
        <p style="font-size: ${isA5 ? '10px' : '12px'}; color: #666; margin: 0;">${company.address}</p>
        <h2 style="font-size: ${isA5 ? '16px' : '20px'}; color: #1E3A8A; margin: 16px 0 0;">SERVICE AGREEMENT</h2>
        <p style="font-size: ${isA5 ? '10px' : '12px'}; color: #666; margin: 4px 0;">Agreement #${orderId}</p>
      </div>

      <div style="font-size: ${fs}; line-height: 1.6;">
        <p>This Service Agreement ("Agreement") is made on <strong>${formatDate(new Date())}</strong> between:</p>

        <p><strong>Service Provider:</strong> ${company.name}, ${company.address}</p>
        <p><strong>Client:</strong> ${form.name || '-'}, ${form.business_name || ''}, ${form.address || ''}, ${form.city || ''}</p>

        <h3 style="font-size: ${isA5 ? '12px' : '14px'}; color: #1E3A8A; margin-top: 16px;">1. PROJECT DETAILS</h3>
        <p>Client has requested a <strong>${order.category || 'Website'}</strong> project. The project will be delivered as per the agreed specifications.</p>

        <h3 style="font-size: ${isA5 ? '12px' : '14px'}; color: #1E3A8A; margin-top: 16px;">2. PAYMENT TERMS</h3>
        <p>Total project cost: <strong>${formatCurrency(total, 'INR')}</strong> (including GST). Payment must be made as per the agreed schedule.</p>

        <h3 style="font-size: ${isA5 ? '12px' : '14px'}; color: #1E3A8A; margin-top: 16px;">3. DELIVERY TIMELINE</h3>
        <p>The project will be delivered within <strong>7-14 working days</strong> after admin approval and payment verification.</p>

        <h3 style="font-size: ${isA5 ? '12px' : '14px'}; color: #1E3A8A; margin-top: 16px;">4. REVISIONS</h3>
        <p>Client is entitled to <strong>2-3 revisions</strong> as per the selected plan. Additional revisions will be charged separately.</p>

        <h3 style="font-size: ${isA5 ? '12px' : '14px'}; color: #1E3A8A; margin-top: 16px;">5. INTELLECTUAL PROPERTY</h3>
        <p>Upon full payment, all intellectual property rights of the final project will be transferred to the Client. Service Provider retains the right to showcase the work in their portfolio.</p>

        <h3 style="font-size: ${isA5 ? '12px' : '14px'}; color: #1E3A8A; margin-top: 16px;">6. REFUND POLICY</h3>
        <p>Full refund if cancelled before work begins. Partial refund (50%) if cancelled after work begins. No refund after final delivery.</p>

        <h3 style="font-size: ${isA5 ? '12px' : '14px'}; color: #1E3A8A; margin-top: 16px;">7. CONFIDENTIALITY</h3>
        <p>Both parties agree to maintain confidentiality of all proprietary information shared during this engagement.</p>

        <h3 style="font-size: ${isA5 ? '12px' : '14px'}; color: #1E3A8A; margin-top: 16px;">8. SUPPORT</h3>
        <p>Free support for <strong>30 days</strong> after delivery. Extended support available as per maintenance plan.</p>

        <h3 style="font-size: ${isA5 ? '12px' : '14px'}; color: #1E3A8A; margin-top: 16px;">9. TERMINATION</h3>
        <p>Either party may terminate this agreement with 7 days written notice. Payment for completed work is non-refundable.</p>

        <h3 style="font-size: ${isA5 ? '12px' : '14px'}; color: #1E3A8A; margin-top: 16px;">10. GOVERNING LAW</h3>
        <p>This agreement is governed by the laws of India. Any disputes will be resolved through mutual discussion.</p>

        <div style="margin-top: 40px; display: flex; justify-content: space-between; gap: 24px;">
          <div style="flex: 1; text-align: center;">
            <div style="border-top: 1px solid #000; padding-top: 8px; margin-top: 40px;">
              <p style="font-size: ${fs}; margin: 0;"><strong>${company.name}</strong></p>
              <p style="font-size: ${fs}; color: #666; margin: 2px 0;">Service Provider</p>
              ${company.signature ? `<img src="${company.signature}" style="height: 40px; margin: 8px 0;" />` : ''}
              ${company.stamp ? `<img src="${company.stamp}" style="height: 50px; opacity: 0.8;" />` : ''}
            </div>
          </div>
          <div style="flex: 1; text-align: center;">
            <div style="border-top: 1px solid #000; padding-top: 8px; margin-top: 40px;">
              <p style="font-size: ${fs}; margin: 0;"><strong>${form.name || '-'}</strong></p>
              <p style="font-size: ${fs}; color: #666; margin: 2px 0;">Client</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
}

/* ============================================
   GENERATE RECEIPT HTML
   ============================================ */

function generateReceiptHTML(size = 'a4') {
  const isA5 = size === 'a5';
  const pageWidth = isA5 ? '148mm' : '210mm';
  const pageHeight = isA5 ? '210mm' : '297mm';
  const padding = isA5 ? '10mm' : '15mm';
  const fs = isA5 ? '11px' : '13px';

  const company = companyData || getDefaultCompanyData();
  const form = formData || {};
  const order = orderData || {};

  const total = (order.final_amount || 0) * 1.18;
  const gst = (order.final_amount || 0) * 0.18;

  return `
    <div class="document-page" style="width: ${pageWidth}; min-height: ${pageHeight}; padding: ${padding}; background: white; font-family: Arial, sans-serif; color: #000;">
      <div style="text-align: center; border-bottom: 2px solid #1E3A8A; padding-bottom: 16px; margin-bottom: 24px;">
        ${company.logo ? `<img src="${company.logo}" style="width: 64px; height: 64px; object-fit: contain; margin: 0 auto 8px;" />` : ''}
        <h1 style="font-size: ${isA5 ? '18px' : '24px'}; color: #1E3A8A; margin: 0 0 4px;">${company.name}</h1>
        <p style="font-size: ${isA5 ? '10px' : '12px'}; color: #666; margin: 0;">${company.address}</p>
        <p style="font-size: ${isA5 ? '10px' : '12px'}; color: #666; margin: 2px 0;">GST: ${company.gst} | 📞 ${company.phone}</p>
        <h2 style="font-size: ${isA5 ? '20px' : '26px'}; color: #10B981; margin: 16px 0 0;">PAYMENT RECEIPT</h2>
      </div>

      <div style="background: #f0fdf4; border: 2px solid #10B981; border-radius: 8px; padding: 16px; text-align: center; margin-bottom: 24px;">
        <p style="font-size: ${isA5 ? '14px' : '18px'}; color: #10B981; font-weight: bold; margin: 0;">✅ PAYMENT RECEIVED</p>
      </div>

      <div style="display: flex; justify-content: space-between; margin-bottom: 24px; gap: 24px;">
        <div style="flex: 1;">
          <h3 style="font-size: ${isA5 ? '12px' : '14px'}; color: #1E3A8A; border-bottom: 1px solid #ddd; padding-bottom: 4px; margin-bottom: 8px;">RECEIVED FROM</h3>
          <p style="font-size: ${fs}; margin: 4px 0;"><strong>${form.name || '-'}</strong></p>
          <p style="font-size: ${fs}; margin: 2px 0;">${form.business_name || '-'}</p>
          <p style="font-size: ${fs}; color: #666; margin: 2px 0;">${form.email || '-'}</p>
        </div>
        <div style="flex: 1;">
          <h3 style="font-size: ${isA5 ? '12px' : '14px'}; color: #1E3A8A; border-bottom: 1px solid #ddd; padding-bottom: 4px; margin-bottom: 8px;">RECEIPT DETAILS</h3>
          <p style="font-size: ${fs}; margin: 4px 0;"><strong>Receipt #:</strong> RCP-${orderId}</p>
          <p style="font-size: ${fs}; margin: 2px 0;"><strong>Date:</strong> ${formatDate(new Date())}</p>
          <p style="font-size: ${fs}; margin: 2px 0;"><strong>Order #:</strong> ${orderId}</p>
        </div>
      </div>

      <table style="width: 100%; border-collapse: collapse; margin-bottom: 24px;">
        <thead>
          <tr style="background: #1E3A8A; color: white;">
            <th style="padding: 10px; text-align: left; font-size: ${fs};">Description</th>
            <th style="padding: 10px; text-align: right; font-size: ${fs};">Amount</th>
          </tr>
        </thead>
        <tbody>
          <tr style="border-bottom: 1px solid #eee;">
            <td style="padding: 12px; font-size: ${fs};">Payment for ${order.category || 'Website'} Development</td>
            <td style="padding: 12px; text-align: right; font-size: ${fs};">${formatCurrency(order.amount || 0, 'INR')}</td>
          </tr>
          ${order.discount > 0 ? `
          <tr style="border-bottom: 1px solid #eee;">
            <td style="padding: 12px; font-size: ${fs}; color: #10B981;">Discount Applied</td>
            <td style="padding: 12px; text-align: right; font-size: ${fs}; color: #10B981;">- ${formatCurrency(order.discount, 'INR')}</td>
          </tr>` : ''}
          <tr style="border-bottom: 1px solid #eee;">
            <td style="padding: 12px; font-size: ${fs};">GST (18%)</td>
            <td style="padding: 12px; text-align: right; font-size: ${fs};">${formatCurrency(gst, 'INR')}</td>
          </tr>
          <tr style="background: #f0fdf4;">
            <td style="padding: 12px; font-size: ${isA5 ? '14px' : '16px'}; font-weight: bold;">TOTAL PAID</td>
            <td style="padding: 12px; text-align: right; font-size: ${isA5 ? '14px' : '16px'}; font-weight: bold; color: #10B981;">${formatCurrency(total, 'INR')}</td>
          </tr>
        </tbody>
      </table>

      <div style="margin-top: 40px; display: flex; justify-content: space-between; align-items: flex-end;">
        <div style="font-size: ${isA5 ? '9px' : '11px'}; color: #666;">
          <p>Payment Mode: UPI / Bank Transfer</p>
          <p>Status: <strong style="color: #10B981;">PAID ✅</strong></p>
          <p>This is a computer-generated receipt.</p>
        </div>
        <div style="text-align: center;">
          ${company.signature ? `<img src="${company.signature}" style="height: 40px; margin-bottom: 4px;" />` : ''}
          <p style="font-size: ${fs}; border-top: 1px solid #000; padding-top: 4px; margin: 0;">Authorized Signature</p>
          ${company.stamp ? `<img src="${company.stamp}" style="height: 60px; margin-top: 8px; opacity: 0.8;" />` : ''}
        </div>
      </div>
    </div>
  `;
}

/* ============================================
   GET DOCUMENT HTML
   ============================================ */

function getDocumentHTML(type, size = 'a4') {
  switch (type) {
    case 'bill':
      return generateBillHTML(size);
    case 'agreement':
      return generateAgreementHTML(size);
    case 'receipt':
      return generateReceiptHTML(size);
    default:
      return '';
  }
}

/* ============================================
   PREVIEW DOCUMENT
   ============================================ */

function previewDocument(type) {
  const html = getDocumentHTML(type, 'a4');
  if (!html) return;

  const modal = document.getElementById('previewModal');
  const content = document.getElementById('previewContent');
  const title = document.getElementById('previewTitle');

  if (modal && content) {
    if (title) title.textContent = type.charAt(0).toUpperCase() + type.slice(1) + ' Preview';
    content.innerHTML = html;
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

export function closePreview() {
  const modal = document.getElementById('previewModal');
  if (modal) {
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }
}

/* ============================================
   DOWNLOAD DOCUMENT (Print to PDF)
   ============================================ */

async function downloadDocument(type, size = 'a4') {
  try {
    const html = getDocumentHTML(type, size);
    if (!html) throw new Error('Document not found');

    // Open print window (user can save as PDF)
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      showToast('Please allow popups to download', 'warning');
      return;
    }

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="UTF-8">
          <title>${type.toUpperCase()} - ${orderId}</title>
          <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: Arial, sans-serif; background: white; }
            @page { size: ${size.toUpperCase()}; margin: 0; }
            @media print {
              body { margin: 0; }
            }
          </style>
        </head>
        <body>${html}</body>
      </html>
    `);
    printWindow.document.close();

    setTimeout(() => {
      printWindow.focus();
      printWindow.print();
    }, 500);

    // Log activity
    const user = await getCurrentUser();
    if (user) {
      await logActivity(user.id, 'document_downloaded', {
        order_id: orderId,
        type,
        size
      });
    }

    showToast(`${type.charAt(0).toUpperCase() + type.slice(1)} ready! Save as PDF.`, 'success');
  } catch (error) {
    console.error('Download error:', error.message);
    showToast('Download failed. Try again.', 'danger');
  }
}

/* ============================================
   PRINT DOCUMENT
   ============================================ */

function printDocument(type) {
  const html = getDocumentHTML(type, 'a4');
  if (!html) return;

  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    showToast('Please allow popups to print', 'warning');
    return;
  }

  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>Print - ${type}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: Arial, sans-serif; }
          @page { size: A4; margin: 0; }
        </style>
      </head>
      <body>${html}</body>
    </html>
  `);
  printWindow.document.close();
  printWindow.focus();

  setTimeout(() => {
    printWindow.print();
  }, 500);
}

/* ============================================
   DOWNLOAD ALL
   ============================================ */

async function downloadAll() {
  const types = ['bill', 'agreement', 'receipt'];

  for (const type of types) {
    await downloadDocument(type, 'a4');
    await new Promise(resolve => setTimeout(resolve, 800));
  }

  showToast('All documents opened! Save each as PDF.', 'success');
}

/* ============================================
   AUTO-INIT
   ============================================ */

if (document.querySelector('[data-doc-type]')) {
  document.addEventListener('DOMContentLoaded', initDocuments);
}

/* ============================================
   EXPORT DEFAULT
   ============================================ */

export default {
  initDocuments,
  closePreview
};