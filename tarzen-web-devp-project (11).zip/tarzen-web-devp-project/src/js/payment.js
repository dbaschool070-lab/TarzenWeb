/* ============================================
   Tarzen Web Devp. — Payment Logic
   QR Code, Coupon, Discount, Screenshot Upload
   ============================================ */

import { supabase, TABLES, BUCKETS, ORDER_STATUS, PAYMENT_STATUS, PRICING_PLANS, logActivity } from './supabase.js';
import { getCurrentUser, requireAuth } from './auth.js';
import {
  showToast,
  showLoading,
  hideLoading,
  formatCurrency,
  formatTimer,
  getQueryParam,
  validateFile,
  formatFileSize,
  previewImage,
  getExchangeRate,
  convertCurrency
} from './app.js';

/* ============================================
   PAYMENT STATE
   ============================================ */

const SCREENSHOT_DURATION = 10 * 60; // 10 minutes

let orderId = null;
let orderData = null;
let formData = null;
let paymentData = {
  plan: 'one-time',
  amountUSD: 500,
  amountINR: 41500,
  currency: 'INR',
  discount: 0,
  discountPercent: 0,
  couponCode: '',
  finalAmountUSD: 500,
  finalAmountINR: 41500,
  qrCodeUrl: ''
};

let screenshotTimer = null;
let screenshotTimeRemaining = SCREENSHOT_DURATION;
let uploadedFile = null;

/* ============================================
   INIT PAYMENT
   ============================================ */

export async function initPayment() {
  const user = await requireAuth();
  if (!user) return;

  orderId = getQueryParam('order');
  if (!orderId) {
    showToast('Order not found', 'danger');
    setTimeout(() => window.location.href = 'dashboard.html', 1500);
    return;
  }

  // Load order
  await loadOrder(user.id);

  // Load QR code
  await loadQRCode();

  // Load pricing
  await loadPricing();

  // Update UI
  updatePaymentUI();

  // Setup controls
  setupControls();

  // Setup coupon
  setupCoupon();

  // Start screenshot timer
  startScreenshotTimer();
}

/* ============================================
   LOAD ORDER
   ============================================ */

async function loadOrder(userId) {
  const { data: order, error } = await supabase
    .from(TABLES.ORDERS)
    .select('*')
    .eq('id', orderId)
    .eq('user_id', userId)
    .single();

  if (error || !order) {
    showToast('Order not found', 'danger');
    setTimeout(() => window.location.href = 'dashboard.html', 1500);
    return;
  }

  orderData = order;

  // Load form data
  const { data: form } = await supabase
    .from(TABLES.FORM_DATA)
    .select('*')
    .eq('order_id', orderId)
    .single();

  formData = form;
}

/* ============================================
   LOAD QR CODE
   ============================================ */

async function loadQRCode() {
  try {
    const { data, error } = await supabase
      .from(TABLES.SETTINGS)
      .select('value')
      .eq('key', 'qr_code')
      .single();

    if (error || !data) {
      console.warn('QR code not found');
      return;
    }

    paymentData.qrCodeUrl = data.value.url || data.value;
    const qrImg = document.getElementById('qrCodeImage');
    if (qrImg) qrImg.src = paymentData.qrCodeUrl;
  } catch (err) {
    console.error('QR load error:', err);
  }
}

/* ============================================
   LOAD PRICING
   ============================================ */

async function loadPricing() {
  try {
    const { data, error } = await supabase
      .from(TABLES.SETTINGS)
      .select('value')
      .eq('key', 'pricing')
      .single();

    if (!error && data) {
      // Use admin-set pricing
      const pricing = data.value;
      paymentData.amountUSD = pricing.one_time?.usd || 500;
      paymentData.amountINR = pricing.one_time?.inr || 41500;
    }

    // Calculate final amounts
    calculateFinalAmounts();
  } catch (err) {
    console.error('Pricing load error:', err);
  }
}

/* ============================================
   CALCULATE AMOUNTS
   ============================================ */

function calculateFinalAmounts() {
  const discountAmountUSD = (paymentData.amountUSD * paymentData.discountPercent) / 100;
  const discountAmountINR = (paymentData.amountINR * paymentData.discountPercent) / 100;

  paymentData.discount = discountAmountINR;
  paymentData.finalAmountUSD = paymentData.amountUSD - discountAmountUSD;
  paymentData.finalAmountINR = paymentData.amountINR - discountAmountINR;
}

/* ============================================
   UPDATE PAYMENT UI
   ============================================ */

function updatePaymentUI() {
  // Order summary
  const categoryEl = document.getElementById('summaryCategory');
  const orderIdEl = document.getElementById('summaryOrderId');
  const businessEl = document.getElementById('summaryBusiness');

  if (categoryEl && orderData) {
    categoryEl.textContent = orderData.category;
  }
  if (orderIdEl) {
    orderIdEl.textContent = orderId;
  }
  if (businessEl && formData) {
    businessEl.textContent = formData.business_name || '-';
  }

  // Price summary
  const amountEl = document.getElementById('summaryAmount');
  const discountEl = document.getElementById('summaryDiscount');
  const totalEl = document.getElementById('summaryTotal');

  if (amountEl) {
    amountEl.textContent = formatCurrency(paymentData.amountINR, 'INR');
  }
  if (discountEl) {
    discountEl.textContent = `- ${formatCurrency(paymentData.discount, 'INR')}`;
    discountEl.parentElement.style.display = paymentData.discount > 0 ? 'flex' : 'none';
  }
  if (totalEl) {
    totalEl.textContent = formatCurrency(paymentData.finalAmountINR, 'INR');
  }

  // USD display
  const usdEl = document.getElementById('summaryAmountUSD');
  if (usdEl) {
    usdEl.textContent = `≈ ${formatCurrency(paymentData.finalAmountUSD, 'USD')}`;
  }
}

/* ============================================
   SETUP CONTROLS
   ============================================ */

function setupControls() {
  const paidBtn = document.getElementById('ivePaid');
  const uploadBtn = document.getElementById('uploadScreenshot');
  const fileInput = document.getElementById('screenshotInput');
  const copyBtn = document.getElementById('copyAmount');
  const skipUploadBtn = document.getElementById('skipUpload');

  if (paidBtn) {
    paidBtn.addEventListener('click', () => {
      showUploadSection();
    });
  }

  if (uploadBtn && fileInput) {
    uploadBtn.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      handleFileSelect(file);
    });
  }

  if (copyBtn) {
    copyBtn.addEventListener('click', () => {
      navigator.clipboard.writeText(paymentData.finalAmountINR.toString());
      showToast('Amount copied!', 'success');
    });
  }

  if (skipUploadBtn) {
    skipUploadBtn.addEventListener('click', () => {
      if (confirm('Skip upload? You can upload later from dashboard.')) {
        goToTracking();
      }
    });
  }

  // Drag & drop
  setupDragDrop();
}

function setupDragDrop() {
  const dropZone = document.getElementById('fileDropZone');
  if (!dropZone) return;

  ['dragenter', 'dragover'].forEach(event => {
    dropZone.addEventListener(event, (e) => {
      e.preventDefault();
      dropZone.classList.add('dragover');
    });
  });

  ['dragleave', 'drop'].forEach(event => {
    dropZone.addEventListener(event, (e) => {
      e.preventDefault();
      dropZone.classList.remove('dragover');
    });
  });

  dropZone.addEventListener('drop', (e) => {
    const file = e.dataTransfer.files[0];
    handleFileSelect(file);
  });
}

/* ============================================
   SHOW UPLOAD SECTION
   ============================================ */

function showUploadSection() {
  const uploadSection = document.getElementById('uploadSection');
  const paymentSection = document.getElementById('paymentSection');

  if (uploadSection) uploadSection.style.display = 'block';
  if (paymentSection) paymentSection.style.display = 'none';

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

/* ============================================
   FILE SELECT
   ============================================ */

async function handleFileSelect(file) {
  if (!file) return;

  const validation = validateFile(file, {
    maxSize: 5 * 1024 * 1024,
    allowedTypes: ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf']
  });

  if (!validation.valid) {
    showToast(validation.error, 'danger');
    return;
  }

  uploadedFile = file;

  // Show preview
  const previewEl = document.getElementById('filePreview');
  const previewImg = document.getElementById('previewImage');
  const fileNameEl = document.getElementById('fileName');
  const fileSizeEl = document.getElementById('fileSize');

  if (previewEl) previewEl.style.display = 'flex';
  if (fileNameEl) fileNameEl.textContent = file.name;
  if (fileSizeEl) fileSizeEl.textContent = formatFileSize(file.size);

  if (file.type.startsWith('image/') && previewImg) {
    try {
      const url = await previewImage(file);
      previewImg.src = url;
      previewImg.style.display = 'block';
    } catch (err) {
      console.error('Preview error:', err);
    }
  }

  // Enable submit
  const submitBtn = document.getElementById('submitScreenshot');
  if (submitBtn) {
    submitBtn.disabled = false;
    submitBtn.onclick = uploadScreenshot;
  }
}

/* ============================================
   UPLOAD SCREENSHOT
   ============================================ */

async function uploadScreenshot() {
  if (!uploadedFile) {
    showToast('Please select a file', 'warning');
    return;
  }

  const submitBtn = document.getElementById('submitScreenshot');
  showLoading(submitBtn);

  try {
    const user = await getCurrentUser();
    if (!user) throw new Error('Not logged in');

    // Upload to Supabase Storage
    const fileName = `${orderId}_${Date.now()}_${uploadedFile.name}`;
    const filePath = `${user.id}/${fileName}`;

    const { data: uploadData, error: uploadError } = await supabase.storage
      .from(BUCKETS.SCREENSHOTS)
      .upload(filePath, uploadedFile, {
        cacheControl: '3600',
        upsert: false
      });

    if (uploadError) throw uploadError;

    // Get signed URL (private bucket)
    const { data: urlData } = await supabase.storage
      .from(BUCKETS.SCREENSHOTS)
      .createSignedUrl(filePath, 60 * 60 * 24 * 365); // 1 year

    const screenshotUrl = urlData?.signedUrl || filePath;

    // Save to payments table
    const { error: paymentError } = await supabase
      .from(TABLES.PAYMENTS)
      .insert({
        order_id: orderId,
        screenshot_url: filePath,
        status: PAYMENT_STATUS.PENDING,
        amount: paymentData.finalAmountINR,
        currency: paymentData.currency,
        coupon_code: paymentData.couponCode,
        discount: paymentData.discount,
        created_at: new Date().toISOString()
      });

    if (paymentError) throw paymentError;

    // Update order status
    await supabase
      .from(TABLES.ORDERS)
      .update({
        status: ORDER_STATUS.SCREENSHOT_UPLOADED,
        amount: paymentData.finalAmountINR,
        discount: paymentData.discount,
        final_amount: paymentData.finalAmountINR,
        currency: paymentData.currency
      })
      .eq('id', orderId);

    // Log activity
    await logActivity(user.id, 'screenshot_uploaded', {
      order_id: orderId,
      file_path: filePath
    });

    // Stop timer
    if (screenshotTimer) clearInterval(screenshotTimer);

    showToast('Screenshot uploaded! Admin will verify shortly.', 'success');
    setTimeout(goToTracking, 1500);
  } catch (error) {
    console.error('Upload error:', error.message);
    showToast('Upload failed. Try again.', 'danger');
  } finally {
    hideLoading(submitBtn);
  }
}

/* ============================================
   COUPON
   ============================================ */

function setupCoupon() {
  const applyBtn = document.getElementById('applyCoupon');
  const input = document.getElementById('couponInput');

  if (applyBtn) {
    applyBtn.addEventListener('click', applyCoupon);
  }

  if (input) {
    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        applyCoupon();
      }
    });
  }
}

async function applyCoupon() {
  const input = document.getElementById('couponInput');
  const code = input?.value.trim().toUpperCase();

  if (!code) {
    showToast('Please enter a coupon code', 'warning');
    return;
  }

  try {
    const { data, error } = await supabase
      .from(TABLES.DISCOUNTS)
      .select('*')
      .eq('code', code)
      .single();

    if (error || !data) {
      showToast('Invalid coupon code', 'danger');
      return;
    }

    // Check expiry
    if (data.expiry && new Date(data.expiry) < new Date()) {
      showToast('Coupon expired', 'danger');
      return;
    }

    // Check usage limit
    if (data.usage_limit && data.used_count >= data.usage_limit) {
      showToast('Coupon usage limit reached', 'danger');
      return;
    }

    // Apply discount
    paymentData.couponCode = code;
    if (data.type === 'percentage') {
      paymentData.discountPercent = data.value;
    } else {
      paymentData.discountPercent = (data.value / paymentData.amountINR) * 100;
    }

    calculateFinalAmounts();
    updatePaymentUI();
    showCouponApplied(code);

    showToast(`Coupon applied! ${data.value}${data.type === 'percentage' ? '%' : '₹'} off`, 'success');
  } catch (error) {
    console.error('Coupon error:', error.message);
    showToast('Failed to apply coupon', 'danger');
  }
}

function showCouponApplied(code) {
  const appliedEl = document.getElementById('couponApplied');
  const codeEl = document.getElementById('appliedCode');
  const inputWrapper = document.getElementById('couponWrapper');

  if (appliedEl) appliedEl.style.display = 'flex';
  if (codeEl) codeEl.textContent = code;
  if (inputWrapper) inputWrapper.style.display = 'none';

  const removeBtn = document.getElementById('removeCoupon');
  if (removeBtn) {
    removeBtn.onclick = removeCoupon;
  }
}

function removeCoupon() {
  paymentData.couponCode = '';
  paymentData.discountPercent = 0;
  calculateFinalAmounts();
  updatePaymentUI();

  const appliedEl = document.getElementById('couponApplied');
  const inputWrapper = document.getElementById('couponWrapper');
  const input = document.getElementById('couponInput');

  if (appliedEl) appliedEl.style.display = 'none';
  if (inputWrapper) inputWrapper.style.display = 'flex';
  if (input) input.value = '';

  showToast('Coupon removed', 'info');
}

/* ============================================
   SCREENSHOT TIMER
   ============================================ */

function startScreenshotTimer() {
  const timerEl = document.getElementById('screenshotTimer');
  const timerTextEl = document.getElementById('screenshotTimerText');

  updateScreenshotTimer();

  screenshotTimer = setInterval(() => {
    screenshotTimeRemaining--;

    if (screenshotTimeRemaining <= 0) {
      clearInterval(screenshotTimer);
      showToast('Time is up! Please upload your screenshot.', 'warning');
      return;
    }

    updateScreenshotTimer();

    if (timerEl) {
      timerEl.classList.remove('warning', 'danger');
      if (screenshotTimeRemaining <= 60) {
        timerEl.classList.add('danger');
      } else if (screenshotTimeRemaining <= 180) {
        timerEl.classList.add('warning');
      }
    }
  }, 1000);
}

function updateScreenshotTimer() {
  const timerTextEl = document.getElementById('screenshotTimerText');
  if (timerTextEl) {
    timerTextEl.textContent = formatTimer(screenshotTimeRemaining);
  }
}

/* ============================================
   GO TO TRACKING
   ============================================ */

function goToTracking() {
  if (screenshotTimer) clearInterval(screenshotTimer);
  window.location.href = `tracking.html?order=${orderId}`;
}

/* ============================================
   CLEANUP
   ============================================ */

export function stopPayment() {
  if (screenshotTimer) {
    clearInterval(screenshotTimer);
    screenshotTimer = null;
  }
}

window.addEventListener('beforeunload', stopPayment);

/* ============================================
   AUTO-INIT
   ============================================ */

if (document.getElementById('qrCodeImage')) {
  document.addEventListener('DOMContentLoaded', initPayment);
}

/* ============================================
   EXPORT DEFAULT
   ============================================ */

export default {
  initPayment,
  stopPayment
};