/* ============================================
   Tarzen Web Devp. — Authentication
   Google Login, Email OTP, Password, Session
   ============================================ */

import { supabase, TABLES, USER_ROLES, logActivity } from './supabase.js';

/* Owner accounts: signing up or logging in with one of these emails makes
   that account an Admin automatically - no dashboard/table step needed. */
const ADMIN_EMAILS = ['tarzenwebtech@outlook.com', 'mayank999625@gmail.com'];
const roleForEmail = (email) =>
  ADMIN_EMAILS.includes((email || '').toLowerCase()) ? USER_ROLES.ADMIN : USER_ROLES.CUSTOMER;

/* Redirect helper: resolves a sibling page (dashboard.html, set-password.html)
   relative to the current page, so auth redirects work no matter which folder
   the site is served from (live-server serves src/pages as the site root, so an
   absolute '/src/pages/...' path would land on a 404 after login). */
const pageUrl = (page) => new URL(page, window.location.href).href;

/* ============================================
   GOOGLE LOGIN
   ============================================ */

export async function signInWithGoogle() {
  try {
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: pageUrl('dashboard.html'),
        queryParams: {
          access_type: 'offline',
          prompt: 'consent'
        }
      }
    });

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Google login error:', error.message);
    return { data: null, error };
  }
}

/* ============================================
   EMAIL OTP
   ============================================ */

export async function sendEmailOTP(email) {
  try {
    const { data, error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        shouldCreateUser: true,
        emailRedirectTo: pageUrl('dashboard.html')
      }
    });

    if (error) throw error;

    // Store email for OTP page
    sessionStorage.setItem('otp_email', email);
    sessionStorage.setItem('otp_sent_at', Date.now().toString());

    return { data, error: null };
  } catch (error) {
    console.error('Send OTP error:', error.message);
    return { data: null, error };
  }
}

export async function verifyEmailOTP(email, token) {
  try {
    const { data, error } = await supabase.auth.verifyOtp({
      email,
      token,
      type: 'email'
    });

    if (error) throw error;

    // Create or update user profile
    if (data.user) {
      await createUserProfile(data.user);
    }

    return { data, error: null };
  } catch (error) {
    console.error('Verify OTP error:', error.message);
    return { data: null, error };
  }
}

export async function resendEmailOTP(email) {
  return sendEmailOTP(email);
}

/* ============================================
   PASSWORD
   ============================================ */

export async function setPassword(password) {
  try {
    const { data, error } = await supabase.auth.updateUser({ password });

    if (error) throw error;

    // Mark password as set in profile
    if (data.user) {
      await supabase
        .from(TABLES.USERS)
        .update({ password_set: true })
        .eq('id', data.user.id);
    }

    return { data, error: null };
  } catch (error) {
    console.error('Set password error:', error.message);
    return { data: null, error };
  }
}

export async function signInWithPassword(email, password) {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) throw error;

    // Make sure a profile row exists (needed for dashboard + admin roles)
    if (data.user) {
      await createUserProfile(data.user);
    }

    return { data, error: null };
  } catch (error) {
    console.error('Password login error:', error.message);
    return { data: null, error };
  }
}

export async function changePassword(currentPassword, newPassword) {
  try {
    // Re-authenticate first
    const user = await getCurrentUser();
    if (!user) throw new Error('Not logged in');

    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: user.email,
      password: currentPassword
    });

    if (signInError) throw new Error('Current password is incorrect');

    const { data, error } = await supabase.auth.updateUser({
      password: newPassword
    });

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Change password error:', error.message);
    return { data: null, error };
  }
}

export async function signUpWithPassword(email, password) {
  try {
    const { data, error } = await supabase.auth.signUp({
      email,
      password
    });

    if (error) throw error;

    // When "Confirm email" is OFF in Supabase, sign-up returns a session and
    // the user is logged in instantly - no email, OTP or link needed.
    if (data.user && data.session) {
      await createUserProfile(data.user);
      await supabase
        .from(TABLES.USERS)
        .update({ password_set: true })
        .eq('id', data.user.id);
      return { data, error: null, needsConfirmation: false };
    }

    // No session means Supabase still requires email confirmation.
    return { data, error: null, needsConfirmation: true };
  } catch (error) {
    console.error('Password sign-up error:', error.message);
    return { data: null, error };
  }
}

/* ============================================
   FORGOT PASSWORD
   ============================================ */

export async function resetPassword(email) {
  try {
    const { data, error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: pageUrl('set-password.html')
    });

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Reset password error:', error.message);
    return { data: null, error };
  }
}

/* ============================================
   SESSION
   ============================================ */

export async function getCurrentUser() {
  try {
    const { data: { user }, error } = await supabase.auth.getUser();
    if (error) throw error;
    return user;
  } catch (error) {
    console.error('Get user error:', error.message);
    return null;
  }
}

export async function getSession() {
  try {
    const { data: { session }, error } = await supabase.auth.getSession();
    if (error) throw error;
    return session;
  } catch (error) {
    console.error('Get session error:', error.message);
    return null;
  }
}

export async function requireAuth() {
  const user = await getCurrentUser();
  if (!user) {
    window.location.href = 'login.html';
    return null;
  }
  return user;
}

export async function requireAdmin() {
  const user = await getCurrentUser();
  if (!user) {
    window.location.href = 'login.html';
    return null;
  }

  const profile = await getUserProfile(user.id);
  if (!profile || profile.role !== USER_ROLES.ADMIN) {
    window.location.href = '../dashboard.html';
    return null;
  }

  return user;
}

export async function signOut() {
  try {
    await supabase.auth.signOut();
    sessionStorage.clear();
    localStorage.removeItem('tarzen-auth-token');
    window.location.href = 'login.html';
  } catch (error) {
    console.error('Sign out error:', error.message);
  }
}

/* ============================================
   USER PROFILE
   ============================================ */

export async function createUserProfile(user) {
  try {
    // Check if profile exists
    const { data: existing } = await supabase
      .from(TABLES.USERS)
      .select('id, email, role')
      .eq('id', user.id)
      .single();

    if (existing) {
      // Auto-promote owner accounts to Admin
      const wanted = roleForEmail(existing.email || user.email);
      if (wanted === USER_ROLES.ADMIN && existing.role !== USER_ROLES.ADMIN) {
        const { data: promoted } = await supabase
          .from(TABLES.USERS)
          .update({ role: USER_ROLES.ADMIN })
          .eq('id', user.id)
          .select()
          .single();
        return promoted || existing;
      }
      return existing;
    }

    // Create new profile
    const { data, error } = await supabase
      .from(TABLES.USERS)
      .insert({
        id: user.id,
        email: user.email,
        name: user.user_metadata?.full_name || user.user_metadata?.name || '',
        role: roleForEmail(user.email),
        password_set: false,
        created_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) throw error;

    await logActivity(user.id, 'user_created', { email: user.email });

    return data;
  } catch (error) {
    console.error('Create profile error:', error.message);
    return null;
  }
}

export async function getUserProfile(userId) {
  try {
    const { data, error } = await supabase
      .from(TABLES.USERS)
      .select('*')
      .eq('id', userId)
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Get profile error:', error.message);
    return null;
  }
}

export async function updateUserProfile(userId, updates) {
  try {
    const { data, error } = await supabase
      .from(TABLES.USERS)
      .update(updates)
      .eq('id', userId)
      .select()
      .single();

    if (error) throw error;

    await logActivity(userId, 'profile_updated', updates);
    return { data, error: null };
  } catch (error) {
    console.error('Update profile error:', error.message);
    return { data: null, error };
  }
}

/* ============================================
   OTP TIMER UTILITIES
   ============================================ */

export function getOTPTimeRemaining() {
  const sentAt = sessionStorage.getItem('otp_sent_at');
  if (!sentAt) return 0;

  const elapsed = Math.floor((Date.now() - parseInt(sentAt)) / 1000);
  const remaining = 300 - elapsed; // 5 minutes
  return remaining > 0 ? remaining : 0;
}

export function getResendCooldown() {
  const sentAt = sessionStorage.getItem('otp_sent_at');
  if (!sentAt) return 0;

  const elapsed = Math.floor((Date.now() - parseInt(sentAt)) / 1000);
  const remaining = 30 - elapsed; // 30 seconds
  return remaining > 0 ? remaining : 0;
}

export function getResendCount() {
  return parseInt(sessionStorage.getItem('otp_resend_count') || '0');
}

export function incrementResendCount() {
  const count = getResendCount() + 1;
  sessionStorage.setItem('otp_resend_count', count.toString());
  return count;
}

export function canResendOTP() {
  return getResendCooldown() === 0 && getResendCount() < 10;
}

export function clearOTPData() {
  sessionStorage.removeItem('otp_email');
  sessionStorage.removeItem('otp_sent_at');
  sessionStorage.removeItem('otp_resend_count');
}

/* ============================================
   PASSWORD VALIDATION
   ============================================ */

export function validatePassword(password) {
  const errors = [];

  if (password.length < 8) {
    errors.push('Password must be at least 8 characters');
  }

  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain at least 1 uppercase letter');
  }

  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain at least 1 lowercase letter');
  }

  if (!/[0-9]/.test(password)) {
    errors.push('Password must contain at least 1 number');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

export function getPasswordStrength(password) {
  let score = 0;

  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[a-z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;

  if (score <= 2) return { level: 'weak', score, label: 'Weak' };
  if (score <= 4) return { level: 'medium', score, label: 'Medium' };
  return { level: 'strong', score, label: 'Strong' };
}

/* ============================================
   EMAIL VALIDATION
   ============================================ */

export function validateEmail(email) {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
}

/* ============================================
   AUTH STATE LISTENER
   ============================================ */

export function onAuthStateChange(callback) {
  return supabase.auth.onAuthStateChange((event, session) => {
    console.log('Auth state changed:', event);
    callback(event, session);
  });
}

/* ============================================
   DELETE ACCOUNT
   ============================================ */

export async function deleteAccount() {
  try {
    const user = await getCurrentUser();
    if (!user) throw new Error('Not logged in');

    // Delete user data from tables
    await supabase.from(TABLES.NOTIFICATIONS).delete().eq('user_id', user.id);
    await supabase.from(TABLES.TICKETS).delete().eq('user_id', user.id);
    await supabase.from(TABLES.USERS).delete().eq('id', user.id);

    // Sign out
    await signOut();
    return { success: true };
  } catch (error) {
    console.error('Delete account error:', error.message);
    return { success: false, error };
  }
}