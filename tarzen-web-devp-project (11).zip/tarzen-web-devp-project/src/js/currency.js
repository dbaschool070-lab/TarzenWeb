/* ============================================
   Tarzen Web Devp. — Currency
   USD ↔ INR Conversion, Exchange Rate, Formatting
   ============================================ */

/* ============================================
   CURRENCY CONFIG
   ============================================ */

const CURRENCY_CONFIG = {
  USD: { symbol: '$', code: 'USD', name: 'US Dollar', locale: 'en-US' },
  INR: { symbol: '₹', code: 'INR', name: 'Indian Rupee', locale: 'en-IN' },
  EUR: { symbol: '€', code: 'EUR', name: 'Euro', locale: 'de-DE' },
  GBP: { symbol: '£', code: 'GBP', name: 'British Pound', locale: 'en-GB' },
  AED: { symbol: 'د.إ', code: 'AED', name: 'UAE Dirham', locale: 'ar-AE' },
  AUD: { symbol: 'A$', code: 'AUD', name: 'Australian Dollar', locale: 'en-AU' },
  CAD: { symbol: 'C$', code: 'CAD', name: 'Canadian Dollar', locale: 'en-CA' },
  SGD: { symbol: 'S$', code: 'SGD', name: 'Singapore Dollar', locale: 'en-SG' }
};

/* ============================================
   FALLBACK RATES (agar API fail ho)
   ============================================ */

const FALLBACK_RATES = {
  USD: 1,
  INR: 83.5,
  EUR: 0.92,
  GBP: 0.79,
  AED: 3.67,
  AUD: 1.52,
  CAD: 1.36,
  SGD: 1.34
};

/* ============================================
   CACHE
   ============================================ */

const CACHE_KEY = 'tarzen_exchange_rates';
const CACHE_DURATION = 60 * 60 * 1000; // 1 hour

let cachedRates = null;

/* ============================================
   GET EXCHANGE RATES
   ============================================ */

export async function getExchangeRates(baseCurrency = 'USD') {
  try {
    // Check cache
    const cached = getFromCache();
    if (cached) {
      return cached;
    }

    // Fetch from API
    const response = await fetch(
      `https://api.exchangerate-api.com/v4/latest/${baseCurrency}`
    );

    if (!response.ok) throw new Error('API failed');

    const data = await response.json();
    const rates = data.rates || FALLBACK_RATES;

    // Save to cache
    saveToCache(rates);

    return rates;
  } catch (error) {
    console.warn('Exchange API failed, using fallback:', error.message);
    return FALLBACK_RATES;
  }
}

/* ============================================
   GET EXCHANGE RATE (Single Pair)
   ============================================ */

export async function getExchangeRate(from = 'USD', to = 'INR') {
  if (from === to) return 1;

  const rates = await getExchangeRates(from);
  return rates[to] || FALLBACK_RATES[to] || 1;
}

/* ============================================
   CONVERT CURRENCY
   ============================================ */

export async function convertCurrency(amount, from = 'USD', to = 'INR') {
  if (from === to) return amount;

  const rate = await getExchangeRate(from, to);
  return amount * rate;
}

/* ============================================
   CONVERT CURRENCY (Sync — uses cached/fallback)
   ============================================ */

export function convertCurrencySync(amount, from = 'USD', to = 'INR') {
  if (from === to) return amount;

  const rates = cachedRates || FALLBACK_RATES;

  // Convert to base (USD), then to target
  const amountInUSD = amount / (rates[from] || 1);
  const result = amountInUSD * (rates[to] || 1);

  return result;
}

/* ============================================
   FORMAT CURRENCY
   ============================================ */

export function formatCurrency(amount, currency = 'INR', options = {}) {
  const config = CURRENCY_CONFIG[currency] || CURRENCY_CONFIG.INR;
  const numAmount = Number(amount) || 0;

  const {
    showSymbol = true,
    showCode = false,
    decimals = 0,
    compact = false
  } = options;

  // Compact format (₹1.2K, $1.5M)
  if (compact) {
    return formatCompact(numAmount, currency, showSymbol);
  }

  const formatted = numAmount.toLocaleString(config.locale, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals
  });

  if (showCode) {
    return `${config.code} ${formatted}`;
  }

  if (showSymbol) {
    return `${config.symbol}${formatted}`;
  }

  return formatted;
}

/* ============================================
   FORMAT COMPACT
   ============================================ */

function formatCompact(amount, currency = 'INR', showSymbol = true) {
  const config = CURRENCY_CONFIG[currency] || CURRENCY_CONFIG.INR;
  const symbol = showSymbol ? config.symbol : '';

  const absAmount = Math.abs(amount);

  if (absAmount >= 10000000) {
    return `${symbol}${(amount / 10000000).toFixed(2)}Cr`;
  }
  if (absAmount >= 100000) {
    return `${symbol}${(amount / 100000).toFixed(2)}L`;
  }
  if (absAmount >= 1000) {
    return `${symbol}${(amount / 1000).toFixed(1)}K`;
  }

  return `${symbol}${amount}`;
}

/* ============================================
   PARSE CURRENCY
   ============================================ */

export function parseCurrency(str) {
  if (typeof str === 'number') return str;

  const cleaned = String(str).replace(/[^\d.-]/g, '');
  return parseFloat(cleaned) || 0;
}

/* ============================================
   GET CURRENCY SYMBOL
   ============================================ */

export function getCurrencySymbol(currency) {
  return CURRENCY_CONFIG[currency]?.symbol || currency;
}

/* ============================================
   GET CURRENCY NAME
   ============================================ */

export function getCurrencyName(currency) {
  return CURRENCY_CONFIG[currency]?.name || currency;
}

/* ============================================
   GET SUPPORTED CURRENCIES
   ============================================ */

export function getSupportedCurrencies() {
  return Object.keys(CURRENCY_CONFIG).map(code => ({
    code,
    ...CURRENCY_CONFIG[code]
  }));
}

/* ============================================
   DETECT USER CURRENCY (IP-based)
   ============================================ */

export async function detectUserCurrency() {
  try {
    const response = await fetch('https://ipapi.co/json/');
    if (!response.ok) throw new Error('IP detection failed');

    const data = await response.json();
    const countryCurrencyMap = {
      IN: 'INR',
      US: 'USD',
      GB: 'GBP',
      EU: 'EUR',
      AE: 'AED',
      AU: 'AUD',
      CA: 'CAD',
      SG: 'SGD'
    };

    return countryCurrencyMap[data.country_code] || 'INR';
  } catch (error) {
    console.warn('Currency detection failed, defaulting to INR');
    return 'INR';
  }
}

/* ============================================
   CACHE MANAGEMENT
   ============================================ */

function saveToCache(rates) {
  try {
    const data = {
      rates,
      timestamp: Date.now()
    };
    sessionStorage.setItem(CACHE_KEY, JSON.stringify(data));
    cachedRates = rates;
  } catch (err) {
    console.error('Cache save error:', err);
  }
}

function getFromCache() {
  try {
    const stored = sessionStorage.getItem(CACHE_KEY);
    if (!stored) return null;

    const data = JSON.parse(stored);
    const age = Date.now() - data.timestamp;

    if (age > CACHE_DURATION) {
      sessionStorage.removeItem(CACHE_KEY);
      return null;
    }

    cachedRates = data.rates;
    return data.rates;
  } catch (err) {
    return null;
  }
}

export function clearCache() {
  sessionStorage.removeItem(CACHE_KEY);
  cachedRates = null;
}

/* ============================================
   PRICING PLANS (with USD + INR)
   ============================================ */

export const PRICING_PLANS = {
  monthly: {
    id: 'monthly',
    name: 'Monthly',
    usd: 20,
    inr: 1650,
    period: 'month'
  },
  yearly: {
    id: 'yearly',
    name: 'Yearly',
    usd: 216,
    inr: 18000,
    period: 'year',
    popular: true
  },
  one_time: {
    id: 'one_time',
    name: 'One-time',
    usd: 500,
    inr: 41500,
    period: 'once'
  },
  with_code: {
    id: 'with_code',
    name: 'With Code',
    usd: 1550,
    inr: 128000,
    period: 'once',
    premium: true
  },
  maintenance: {
    id: 'maintenance',
    name: 'Maintenance',
    usd: 10,
    inr: 825,
    period: 'month'
  }
};

/* ============================================
   GET PLAN PRICE
   ============================================ */

export function getPlanPrice(planId, currency = 'INR') {
  const plan = PRICING_PLANS[planId];
  if (!plan) return 0;

  return currency === 'USD' ? plan.usd : plan.inr;
}

/* ============================================
   CALCULATE GST
   ============================================ */

export function calculateGST(amount, gstPercent = 18) {
  const gst = (amount * gstPercent) / 100;
  return {
    base: amount,
    gst,
    total: amount + gst,
    gstPercent
  };
}

/* ============================================
   CALCULATE DISCOUNT
   ============================================ */

export function calculateDiscount(amount, discountPercent) {
  const discount = (amount * discountPercent) / 100;
  return {
    original: amount,
    discount,
    final: amount - discount,
    discountPercent
  };
}

/* ============================================
   CALCULATE TOTAL (with GST + Discount)
   ============================================ */

export function calculateTotal(amount, options = {}) {
  const {
    discountPercent = 0,
    gstPercent = 18,
    includeGST = true
  } = options;

  // Apply discount
  const discount = (amount * discountPercent) / 100;
  const afterDiscount = amount - discount;

  // Apply GST
  const gst = includeGST ? (afterDiscount * gstPercent) / 100 : 0;
  const total = afterDiscount + gst;

  return {
    base: amount,
    discount,
    discountPercent,
    afterDiscount,
    gst,
    gstPercent: includeGST ? gstPercent : 0,
    total
  };
}

/* ============================================
   FORMAT PRICE RANGE
   ============================================ */

export function formatPriceRange(min, max, currency = 'INR') {
  return `${formatCurrency(min, currency)} - ${formatCurrency(max, currency)}`;
}

/* ============================================
   ROUND TO NEAREST
   ============================================ */

export function roundToNearest(amount, nearest = 1) {
  return Math.round(amount / nearest) * nearest;
}

/* ============================================
   UPDATE ALL PRICE ELEMENTS
   ============================================ */

export function updatePriceElements(currency = 'INR') {
  document.querySelectorAll('[data-price-usd]').forEach(el => {
    const usd = parseFloat(el.dataset.priceUsd);
    if (currency === 'USD') {
      el.textContent = formatCurrency(usd, 'USD');
    } else {
      const rate = cachedRates?.INR || FALLBACK_RATES.INR;
      el.textContent = formatCurrency(usd * rate, 'INR');
    }
  });
}

/* ============================================
   INIT CURRENCY
   ============================================ */

export async function initCurrency() {
  try {
    await getExchangeRates('USD');
    console.log('✅ Currency rates loaded');
  } catch (err) {
    console.warn('Currency init failed, using fallback');
  }
}

/* ============================================
   EXPORT DEFAULT
   ============================================ */

export default {
  getExchangeRates,
  getExchangeRate,
  convertCurrency,
  convertCurrencySync,
  formatCurrency,
  parseCurrency,
  getCurrencySymbol,
  getCurrencyName,
  getSupportedCurrencies,
  detectUserCurrency,
  clearCache,
  PRICING_PLANS,
  getPlanPrice,
  calculateGST,
  calculateDiscount,
  calculateTotal,
  formatPriceRange,
  roundToNearest,
  updatePriceElements,
  initCurrency
};