/* ============================================
   Tarzen Web Devp. — Theme Manager
   Light / Dark theme with persistence.

   - The active theme lives on <html data-theme="...">.
   - A tiny inline bootstrap script in each page <head> applies the
     saved theme before first paint (no flash).
   - This script is the SINGLE owner of the toggle behaviour: some
     pages historically attached their own click handlers (app.js and
     per-page setup functions), which toggled twice per click. The
     capture-phase delegated listener below intercepts toggle clicks
     first and stops the event, so exactly one toggle happens.
   - The choice is stored under "tarzen-theme" and mirrored to the
     legacy "theme" key used by older page scripts.
   ============================================ */

(function () {
  'use strict';

  var PRIMARY_KEY = 'tarzen-theme';
  var LEGACY_KEY = 'theme';

  function storedTheme() {
    try {
      return localStorage.getItem(PRIMARY_KEY) || localStorage.getItem(LEGACY_KEY);
    } catch (e) {
      return null;
    }
  }

  function currentTheme() {
    return document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  }

  function persist(theme) {
    try {
      localStorage.setItem(PRIMARY_KEY, theme);
      localStorage.setItem(LEGACY_KEY, theme);
    } catch (e) {
      /* storage unavailable (private mode) — theme still applies for this page */
    }
  }

  function paintToggle(btn, theme) {
    if (!btn) return;
    btn.textContent = theme === 'dark' ? '☀️' : '🌙';
    btn.setAttribute('aria-label', theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme');
    btn.setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false');
  }

  function applyTheme(theme, save) {
    document.documentElement.setAttribute('data-theme', theme);
    if (save !== false) persist(theme);
    paintToggle(document.getElementById('themeToggle'), theme);
  }

  function toggleTheme() {
    applyTheme(currentTheme() === 'dark' ? 'light' : 'dark', true);
  }

  /* --- Own every #themeToggle click (capture phase, before any
         page-level handler can fire) --- */
  document.addEventListener('click', function (event) {
    var target = event.target;
    var btn = target && target.closest ? target.closest('#themeToggle') : null;
    if (!btn) return;
    event.preventDefault();
    event.stopPropagation();
    if (typeof event.stopImmediatePropagation === 'function') {
      event.stopImmediatePropagation();
    }
    toggleTheme();
  }, true);

  /* --- Initial paint of the toggle + keep storage keys in sync if
         anything else flips the attribute --- */
  function init() {
    var saved = storedTheme();
    if (saved === 'dark' || saved === 'light') {
      applyTheme(saved, true);
    } else {
      paintToggle(document.getElementById('themeToggle'), currentTheme());
    }

    if (window.MutationObserver) {
      var observer = new MutationObserver(function () {
        var theme = currentTheme();
        persist(theme);
        paintToggle(document.getElementById('themeToggle'), theme);
      });
      observer.observe(document.documentElement, {
        attributes: true,
        attributeFilter: ['data-theme']
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  /* Public API (used by the dashboard page's theme setup hook) */
  window.TarzenTheme = {
    get: currentTheme,
    set: function (theme) { applyTheme(theme, true); },
    toggle: toggleTheme
  };
})();
