-- Tarzen Web Devp. - Admin RLS fix (run ONCE in Supabase: SQL Editor -> New query -> paste -> Run)
-- Prepared 2026-10-16.
--
-- WHY: public.is_admin() in the shipped supabase-schema.sql compared the
-- logged-in email against the placeholder 'admin@example.com'. The real admin
-- policies for orders / payments / documents / settings (and the admin
-- screenshot read) all depend on is_admin(), so a real admin logging in with
-- tarzenwebtech@outlook.com or mayank999625@gmail.com would still be treated
-- as a normal customer by Row Level Security: the Admin Panel could not list
-- or approve other customers' orders, and settings writes would be blocked.
-- The app-side auto-admin list (ADMIN_EMAILS in src/js/auth.js) was already
-- correct - only this database function was wrong.
--
-- This file only replaces that one function. It changes no data and is safe
-- to run more than once. The same fix is already applied inside
-- supabase-schema.sql, so fresh setups do not need this file.

create or replace function public.is_admin() returns boolean
language sql stable as $$
  select coalesce(auth.jwt() ->> 'email', '') in
    ('tarzenwebtech@outlook.com', 'mayank999625@gmail.com')
$$;

-- CHECK (optional, run after logging in as admin in the app):
--   select public.is_admin();   -- must return true for an admin login,
--                               -- false for a normal customer login.
