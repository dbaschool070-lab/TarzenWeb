# Tarzen Web Devp. — Supabase Go-Live Guide (updated 2026-10-15)

## Current Status (verified)
- ✅ You have provided your Supabase Project URL and keys — they have been added to the
  project's `.env` and `src/js/supabase.js`, and Supabase Auth responded OK with the
  anon key (the connection is live).
- ⚠️ **Storage buckets are still missing** — a live check on 2026-10-16 found the
  Storage bucket list empty, so uploads (payment screenshots, QR, stamp,
  signature, documents) will fail until **`supabase-storage.sql`** in the project
  root is run once in the SQL Editor (Step 1b below).
- ✅ **Database tables have been created** — the schema has been run, and a live
  re-check through the Supabase REST API returned HTTP 200 for `orders` (empty) and
  the `settings` seed row (id 1). (The schema file is `supabase-schema.sql` in the
  project root — it creates the 9 tables, 8 storage buckets and RLS policies the code
  expects, including a compatibility patch for the exact field names the JS sends:
  `business`, `createdAt`, `discountInr`, `screenshot`, `approvedAt`.)
- ✅ Admin emails are set to the real ones (fixed 2026-10-16): the schema's
  `is_admin()` function and `ADMIN_EMAILS` in `src/js/auth.js` both list
  tarzenwebtech@outlook.com and mayank999625@gmail.com, and `.env`'s
  `ADMIN_EMAIL` is the business email. If the OLD schema (with the
  `admin@example.com` placeholder) was already run in Supabase, run the small
  **`supabase-admin-fix.sql`** once in the SQL Editor — otherwise RLS will
  treat the admin as a normal customer and the Admin Panel will not see all
  orders (see Step 2).

## A note about the sample values in `.env`
Some company values in `.env` are **samples, not real details**:
`COMPANY_ADDRESS` ("Your Address, City, State, India") and `COMPANY_GST`
("GSTIN123456789"); `COMPANY_PHONE` is blank. `ADMIN_EMAIL` and `COMPANY_EMAIL`
are set to the real business email, tarzenwebtech@outlook.com — the only public
contact email (the only other public contact channel is in-app support). Replace
the sample address and GSTIN with your real company details before serving real
customers — the address, GSTIN, phone and email are printed on the Bill,
Agreement and Receipt.

## Step 1 — Tables + Buckets (one time only, ~5 minutes) — DONE, kept for reference
1. Supabase Dashboard → your project → **SQL Editor** → **New query**
2. Open this project's **`supabase-schema.sql`** file, copy the whole file and paste it
   (the file ends with a compatibility patch — it creates exactly the columns the code
   sends: `business`, `createdAt`, `discountInr`, `screenshot`, `approvedAt`; without
   it, form inserts would fail)
3. No find-and-replace needed: the `is_admin()` function at the end of the file
   already contains the real admin emails (see Step 2)
4. Press **Run** → it should succeed
5. Verify: **Table Editor** should show 9 tables — users, orders, payments, documents,
   coupons, tickets, notifications, settings, activity_logs — and **Storage** should
   show 8 buckets, all public (the app reads them via public URLs)

## Step 1b — Storage buckets (run if Storage is empty, ~2 minutes)
> **Existing live database (set up before 2026-10-16)? Run `supabase-go-live.sql`
> instead** — it combines this step and the Step 2 admin fix into one idempotent
> paste, and re-running the full schema on a live database is NOT safe (its base
> policies have no drop-if-exists).
1. Supabase Dashboard → **SQL Editor** → **New query**
2. Open **`supabase-storage.sql`** (project root), paste the whole file, press **Run**
3. Verify: **Storage** should list 8 buckets — screenshots, qr-codes, documents,
   stamps, signatures, project-files, avatars, demo-templates. The file is safe to
   re-run; it also corrects the public flag on any bucket an older schema created
   with the wrong setting.

## Step 2 — Admin emails (already set — one fix if the old schema was run)
The admin list lives in exactly two places, and both already match:
1. `src/js/auth.js` → `ADMIN_EMAILS` (app-side: assigns the admin role on login)
2. `supabase-schema.sql` → `is_admin()` (database-side: RLS lets the admin see
   and approve ALL orders, write settings, and read payment screenshots)
Both list: tarzenwebtech@outlook.com and mayank999625@gmail.com.
⚠️ If you ran the schema BEFORE 2026-10-16, your live database still has the
old placeholder version of `is_admin()`. Fix it once: Supabase → SQL Editor →
paste **`supabase-admin-fix.sql`** → Run. Safe to re-run; it changes no data.

## Step 3 — Email OTP Setup (full process)
The app uses the Email OTP flow (`src/js/auth.js` calls `signInWithOtp` + `verifyOtp`).
Real email OTP is **not live yet** — until these steps are complete and verified, the
app keeps using the demo OTP shown inside the app.

1. **Turn Email login ON:** Dashboard → **Authentication → Sign In / Providers →
   Email** → enable and Save.
2. **Put the OTP code in the email template (most important step):** Dashboard →
   **Authentication → Email Templates → "Magic Link or OTP"**. The message body must
   contain this line:
   `Your OTP code is: {{ .Token }}`
   If the template only contains a link (`{{ .ConfirmationURL }}`), customers will
   receive a link, **not a 6-digit code** — this is the most common mistake.
3. **OTP settings:** Dashboard → **Authentication → Settings** (Email section):
   OTP Length **6**, OTP Expiry **600 seconds (10 minutes)** — matching the app flow.
   The app already enforces a 30-second resend gap.
4. **Custom SMTP for production (required for real customers):** Supabase's built-in
   email service is for testing only — it sends very few emails and they can land in
   spam. Testing works with it, but for real customers go to Dashboard → **Project
   Settings → Authentication → SMTP Settings**, enable Custom SMTP, and enter the
   details of one provider — **Resend / Brevo / SendGrid** (recommended), or **Gmail
   SMTP** (requires a Google App Password — enter it directly in the dashboard,
   never share it in chat).
5. **Test it:** In the app, enter your email on the login page → Send OTP → check your
   inbox (and spam folder) — a 6-digit code should arrive → enter it → you should be
   logged in. In Dashboard → **Authentication → Users**, your email should now appear
   as a user.
6. Only **after** the email arrives and the test passes should the demo OTP be
   switched off in the app — switching earlier would lock everyone (including you)
   out of login. If the OTP does not arrive, check: the `{{ .Token }}` line in the
   template, the spam folder, and that the Email provider is ON (Step 1 above).

## Step 4 — Add the admin's real assets from inside the app
Run the app (`npm install` → `npm run dev` → http://localhost:8080) → Admin:
1. **Admin → QR page:** your real UPI QR image + UPI ID
2. **Admin → Company page:** real address, phone, email, GST, logo, **stamp** and
   **signature** (these appear on the Agreement)
3. **Admin → Pricing page:** verify the defaults — Monthly $20, Yearly $216,
   One-time $500, With Code $1550, Maintenance separate

## Step 5 — Test the complete flow yourself
As a customer: Landing → Email OTP Login → Form (pick 1 category) → Demo
(5-minute timer) → QR Payment → Screenshot upload.
As the admin: Does the order appear under Pending? → View the screenshot →
**Approve** → then, in the customer dashboard, download the Bill, the Agreement
(with stamp + signature) and the Receipt in A4 + A5 and check them.
If everything passes, the app is ready for real customers. Documents are delivered
only inside the app — never sent outside the app — that strict rule is built into the code.

## Please Note
- Do not send your keys in chat again; everything that needed to be added has been added.
- Never put a `service_role` / secret key in browser code or in the client part of
  `.env` — the app only uses the anon/publishable key, and security comes from the
  RLS policies (included in the schema).
- Older ZIPs (88 files) do NOT contain this schema or these keys — if you rebuild
  the ZIP, think before letting the real `.env` values go into it; if the ZIP has to
  be sent to someone, use a copy with placeholder `.env` values instead.
- The hosted app (the one that opens without running any code) now also has the
  Supabase project URL and publishable browser key configured (Admin → Templates,
  with a live status check) — but real email OTP is not live there either yet;
  it still runs on demo OTP until Step 3 is completed and verified.
